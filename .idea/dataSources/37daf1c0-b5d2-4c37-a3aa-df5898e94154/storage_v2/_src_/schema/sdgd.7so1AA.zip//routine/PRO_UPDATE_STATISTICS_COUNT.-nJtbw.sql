create
    definer = root@`%` procedure PRO_UPDATE_STATISTICS_COUNT(IN IN_TYPE varchar(20), IN IN_CALLER varchar(20),
                                                             OUT EXEC_RESULT varchar(10))
mdc:BEGIN
	
	declare  TMP_HOUR_1            INT;
  declare TMP_HOUR_2              INT;
  declare TMP_OTHERNET_HOUR_COUNT INT;
		
	SET TMP_OTHERNET_HOUR_COUNT = 0;

  SELECT date_format(SYSDATE, '%Y-%m-%d %h:%M:%S') INTO TMP_HOUR_1 FROM DUAL;

  SELECT CHECK_HOUR
    INTO TMP_HOUR_2
    FROM EC_TBL_USER_SEND_COUNT A
   WHERE A.USER_ID = (SELECT USER_ID
                        FROM EC_TBL_USER B
                       WHERE A.USER_ID = B.USER_ID
                         AND B.TELEPHONE = IN_CALLER
                         AND LOWER(B.IS_VALID) = 'y');

  IF TMP_HOUR_1 <> TMP_HOUR_2 THEN
    -- 清零
    UPDATE EC_TBL_USER_SEND_COUNT A
       SET A.IN_HOUR_COUNT  = 0,
           A.OUT_HOUR_COUNT = 0,
           A.CHECK_HOUR     = TMP_HOUR_1
     WHERE A.USER_ID = (SELECT USER_ID
                          FROM EC_TBL_USER B
                         WHERE A.USER_ID = B.USER_ID
                           AND B.TELEPHONE = IN_CALLER
                           AND LOWER(B.IS_VALID) = 'y');
  END IF;

  IF IN_TYPE = '0' THEN
    UPDATE EC_TBL_USER_SEND_COUNT A
       SET A.IN_HOUR_COUNT = A.IN_HOUR_COUNT + 1
     WHERE A.USER_ID = (SELECT USER_ID
                          FROM EC_TBL_USER B
                         WHERE A.USER_ID = B.USER_ID
                           AND B.TELEPHONE = IN_CALLER
                           AND LOWER(B.IS_VALID )= 'y');
  ELSEIF IN_TYPE = '1' THEN
    UPDATE EC_TBL_USER_SEND_COUNT A
       SET A.OUT_HOUR_COUNT = A.OUT_HOUR_COUNT + 1
     WHERE A.USER_ID = (SELECT USER_ID
                          FROM EC_TBL_USER B
                         WHERE A.USER_ID = B.USER_ID
                           AND B.TELEPHONE = IN_CALLER
                           AND LOWER(B.IS_VALID )= 'y');
  END IF;

  SELECT A.IN_HOUR_COUNT + A.OUT_HOUR_COUNT
    INTO TMP_OTHERNET_HOUR_COUNT
    FROM EC_TBL_USER_SEND_COUNT A
   WHERE A.USER_ID = (SELECT USER_ID
                        FROM EC_TBL_USER B
                       WHERE A.USER_ID = B.USER_ID
                         AND B.TELEPHONE = IN_CALLER
                         AND LOWER(B.IS_VALID) = 'y');

  IF TMP_OTHERNET_HOUR_COUNT > 100 THEN
    SET EXEC_RESULT = '1';
  ELSE
    SET EXEC_RESULT = '0';
  END IF;
	
END;

