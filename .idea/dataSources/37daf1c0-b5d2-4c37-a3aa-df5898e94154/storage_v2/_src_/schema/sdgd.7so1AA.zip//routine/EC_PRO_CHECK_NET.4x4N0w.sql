create
    definer = root@`%` procedure EC_PRO_CHECK_NET(IN IN_OWNER varchar(30), OUT EXEC_RESULT varchar(10))
mdc:BEGIN

		declare TMP_COUNT    int;
    declare TMP_NET_FLAG VARCHAR(5);

		select 100;
		  SELECT COUNT(*)
      INTO TMP_COUNT
      FROM EC_TBL_NET A
     WHERE IS_VALID = 'Y'
       AND A.NET_NUMBER = SUBSTR(IN_OWNER, 0, LENGTH(A.NET_NUMBER));
    IF TMP_COUNT > 0 THEN
      SELECT NET_FLAG
        INTO TMP_NET_FLAG
        FROM EC_TBL_NET A
       WHERE IS_VALID = 'Y'
         AND A.NET_NUMBER = SUBSTR(IN_OWNER, 0, LENGTH(A.NET_NUMBER));
    select 101;
      IF TMP_NET_FLAG = '0' THEN
        set EXEC_RESULT = '0'; -- 本网
      ELSE
        set EXEC_RESULT = '1'; -- 异网
      END IF;
    ELSE
		select 102;
      set EXEC_RESULT = '1';
    END IF;
		leave mdc;
    -- RETURN;
END;

