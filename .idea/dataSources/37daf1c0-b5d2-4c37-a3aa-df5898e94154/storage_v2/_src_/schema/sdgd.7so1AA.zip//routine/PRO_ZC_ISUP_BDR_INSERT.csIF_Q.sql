create
    definer = root@`%` procedure PRO_ZC_ISUP_BDR_INSERT(IN IN_START_TIME varchar(20), IN IN_CALL_RESULT varchar(10),
                                                        IN IN_REL_CAUSE int(10), IN IN_CALLING varchar(20),
                                                        IN IN_CALLED varchar(20), IN IN_TALK_TIME int(10),
                                                        OUT EXEC_RESULT varchar(20))
mdc:BEGIN
	
	declare TMP_T              VARCHAR(50);
  declare TMP_MESSAGE        VARCHAR(1024);
  declare TMP_COUNT          int;
  declare TMP_COUNT2         int;
  declare TMP_COUNT3         int;
  declare TMP_CALLED         VARCHAR(30);
  declare TMP_CYCLEDATE      int;
  declare TMP_PREFIX         VARCHAR(300);
  declare TMP_SUFFIX         VARCHAR(300);
  declare TMP_FIVEYDATE      VARCHAR(5);
  declare TMP_START_DATE     DATE;
  declare TMP_START_DATE_STR VARCHAR(30);
  declare TMP_CALLSTATUS     int;
  declare TMP_ENCRYPTCALLING varchar(30);
  declare TMP_ENCRYPTCALLED  varchar(30);
		
  set TMP_CALLSTATUS = 0;
  
  set TMP_ENCRYPTCALLING = IN_CALLING;
  set TMP_ENCRYPTCALLED = IN_CALLED;
  -- 主叫为空直接pass
  IF IN_CALLING IS NULL THEN
    set EXEC_RESULT := 0;
    leave mdc;
  END IF;

  set TMP_START_DATE     = str_to_date(IN_START_TIME, '%Y%m%d%H%i%s');
  set TMP_START_DATE_STR  = date_format(TMP_START_DATE, '%Y-%m-%d %H:%i:%s');
  

 select count(*) into TMP_COUNT from EC_TBL_USER where telephone = TMP_ENCRYPTCALLED and is_valid = 'Y';
 
 if TMP_COUNT > 0 then
    INSERT INTO ZC_ISUP_BDR
      (START_TIME, CALL_RESULT, REL_CAUSE, CALLING, CALLED, TALK_TIME)
    VALUES
      (TMP_START_DATE,
       IN_CALL_RESULT,
       IN_REL_CAUSE,
       TMP_ENCRYPTCALLING,
       TMP_ENCRYPTCALLED,
       IN_TALK_TIME);
    COMMIT;
    
    IF IN_TALK_TIME > 0 THEN
      set TMP_CALLSTATUS = 1;
    END IF;
    -- 进入挂机短信下发逻辑
    call EC_PRO_PROCESS_CC(IN_CALLING,IN_CALLED,IN_CALLED,IN_START_TIME,IN_START_TIME,IN_START_TIME,TMP_CALLSTATUS,EXEC_RESULT);
 end if;
  
  set EXEC_RESULT = 0;

		
END;

