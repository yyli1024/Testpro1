create definer = root@`%` trigger TRI_USER_AUI1
    after update
    on ec_tbl_user
    for each row
begin
		DECLARE TMP_STATUS CHAR(1);
		IF UPPER(OLD.IS_VALID) = 'Y' THEN
    set TMP_STATUS = '1';
  ELSE
    set TMP_STATUS = '0';
  END IF;
	  UPDATE EC_TBL_USER_SEND_COUNT
         SET TAOCAN_ID = NEW.TAOCAN_ID, IS_OUTSEND = NEW.IS_GON
       WHERE USER_ID = NEW.USER_ID;

      UPDATE EC_TBL_USERINFO
         SET STATUS = TMP_STATUS, UPDATETIME = SYSDATE()
       WHERE PHONENUMBER = NEW.TELEPHONE;
end;

