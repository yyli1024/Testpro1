create
    definer = root@`%` procedure EC_PRO_CREATE_SMS(IN IN_CALLING varchar(30), IN IN_PHONENUMBER varchar(30),
                                                   IN IN_SMSID varchar(20), IN IN_PLS_MESSAGE varchar(512),
                                                   IN IN_MESSAGEMODIFYFLAG int, IN IN_Tally varchar(20),
                                                   IN IN_UNIQUECODE int, OUT EXEC_RESULT varchar(10))
mdc:BEGIN
declare TMP_SYSDATE          DATE;
    declare TMP_MAXLEN           INT;
    declare TMP_SUBLEN           INT;
    declare TMP_LENGTH           INT;
    declare TMP_LOOPCOUNT        INT;
    declare TMP_MSG              VARCHAR(256);
    declare TMP_TAOCANMSGCOUNT   INT;
    declare TMP_USERSENDMSGCOUNT INT;
    declare TMP_COUNT            INT;
    declare TMP_RESULT           VARCHAR(1);
    declare TMP_MESSAGE          VARCHAR(1024);
    declare TMP_MESSAGE1         VARCHAR(1024);
    declare TMP_MESSAGE2         VARCHAR(1024);
    declare TMP_USERID           VARCHAR(32);
    declare TMP_VR_URL           VARCHAR(256);
    declare TMP_UNIQUE_SEQ       VARCHAR(20);
    declare TMP_ENCRYPTCALLING   varchar(30);
    declare TMP_ENCRYPTCALLED    varchar(30);
		declare TMP_ISFS             varchar(10);
	declare TMP_FLAG             INT;
	declare TMP_MOD              INT;
	declare TMP_SENDCOUNT        INT;

	SET TMP_SYSDATE = SYSDATE();
	SET TMP_ENCRYPTCALLING = IN_CALLING;
	SET TMP_ENCRYPTCALLED  = IN_PHONENUMBER;
	SET TMP_FLAG = 0;
	set EXEC_RESULT = 0;
select 11;
    IF IN_PLS_MESSAGE IS NULL THEN
      LEAVE MDC;
    END IF;

    SET TMP_MESSAGE = IN_PLS_MESSAGE;
	
    call EC_PRO_CHECK_NET(IN_CALLING, TMP_RESULT);
		
		select 22;
	-- 免打扰组
	select count(*) into TMP_COUNT from gjdx_client where telephone = IN_CALLING and is_valid = 'N' and user_id in (select user_id from gjdx_user where user_name = IN_PHONENUMBER);
	
	if TMP_COUNT > 0 then
	  set EXEC_RESULT = 13;
		leave mdc;
	end if;
	
	-- 黑名单
	
	select count(*) into TMP_COUNT from ec_tbl_old_blacklist where INSTR(blacklist, IN_CALLING) and telephone = IN_PHONENUMBER;
	
	if TMP_COUNT > 0 then
	set EXEC_RESULT = 14;
		leave mdc;
	end if;
	
	
	select count(*) into TMP_COUNT from ec_tbl_old_blacklist where INSTR(blacklist, concat(left(IN_CALLING,3),',')) and telephone = IN_PHONENUMBER;
	
	if TMP_COUNT > 0 then
	set EXEC_RESULT = 15;
		leave mdc;
	end if;
	
	select count(*) into TMP_COUNT from ec_tbl_old_blacklist where INSTR(left(blacklist,2), '1,') and telephone = IN_PHONENUMBER;
	
	if TMP_COUNT > 0 then
	set EXEC_RESULT = 16;
		leave mdc;
	end if;
	
	
	
	-- 判断是否在全局黑名单中
	   SELECT COUNT(*)
      INTO TMP_COUNT
      FROM GJDX_BLACK
     WHERE telephone = IN_CALLING;
  
    IF TMP_COUNT > 0 THEN
      set EXEC_RESULT = '17';
			leave mdc;   
    END IF;
			select 23;
      SELECT COUNT(*)
        INTO TMP_COUNT
        FROM GJDX_USER D
       WHERE D.TELEPHONE = TMP_ENCRYPTCALLED
		and IS_VALID = 'Y';
    
      IF TMP_COUNT > 0 THEN
			
				select ISFS
        into TMP_ISFS
        from GJDX_USER
       where is_valid = 'Y'
         and telephone = TMP_ENCRYPTCALLED;
			
	  
		  select count(*)
        into tmp_count
        from GJDX_SMSCOUNT
       where is_valid = 'Y'
         and telephone = TMP_ENCRYPTCALLED;
		 
		 if tmp_count > 0 then
		 
			 select count_num
				into TMP_USERSENDMSGCOUNT
				from GJDX_SMSCOUNT
			   WHERE is_valid = 'Y' and telephone = TMP_ENCRYPTCALLED;
			   SET TMP_MESSAGE = IN_PLS_MESSAGE;
		 else
			set EXEC_RESULT = '18';
			leave mdc;
		 end if;  
      ELSE
				set EXEC_RESULT = '19';
        leave mdc;
      END IF;
    
 	select 24;
      set TMP_LENGTH = char_length(TMP_MESSAGE);
    
      IF IN_MESSAGEMODIFYFLAG = 1 or (TMP_USERSENDMSGCOUNT <= 0 and TMP_ISFS = 'N') THEN
			   select 25;
			  set EXEC_RESULT = '20';
        leave mdc;
      ELSE
					IF TMP_LENGTH < 71 THEN
						SET TMP_SENDCOUNT = 1;
					ELSE
						SET TMP_SENDCOUNT = ceil(TMP_LENGTH/65);
					END IF;
					
					if (TMP_USERSENDMSGCOUNT > TMP_SENDCOUNT) or TMP_ISFS = 'Y' then
						IF TMP_LENGTH < 71 THEN
							if TMP_RESULT = '0' THEN 
								select 0;
								INSERT INTO EC_TBL_SHORTMESSAGE_sgip_tmp
									(OWNER,
									 CALLER,
									 ORGTYPE,
									 ORGID,
									 SMSMESSAGE,
									 MESSAGE,
									 CREATETIME,
									 STATUS,
									 OPERATORNO,
									 UNIQUECODE)
								VALUES
									(IN_CALLING,
									 IN_PHONENUMBER,
									 'l',
									 0,
									 TMP_MESSAGE,
									 TMP_MESSAGE,
									 SYSDATE(),
									 '0',
									 '0',
									 IN_UNIQUECODE);
							else
								 select 1;
									INSERT INTO EC_TBL_SHORTMESSAGE_smpp_tmp
									(OWNER,
									 CALLER,
									 ORGTYPE,
									 ORGID,
									 SMSMESSAGE,
									 MESSAGE,
									 CREATETIME,
									 STATUS,
									 OPERATORNO,
									 UNIQUECODE)
								VALUES
									(IN_CALLING,
									 IN_PHONENUMBER,
									 'l',
									 0,
									 TMP_MESSAGE,
									 TMP_MESSAGE,
									 SYSDATE(),
									 '0',
									 '0',
									 IN_UNIQUECODE);
							 end if;
							update GJDX_SMSCOUNT
							set count_num = count_num - 1
							WHERE telephone = IN_PHONENUMBER AND is_valid = 'Y' and count_num > 0;
						else
							if TMP_RESULT = '0' THEN 
								select 2;
								INSERT INTO EC_TBL_SHORTMESSAGE_sgip_tmp
								(OWNER,
								CALLER,
								ORGTYPE,
								ORGID,
								SMSMESSAGE,
								MESSAGE,
								CREATETIME,
								STATUS,
								OPERATORNO,
								UNIQUECODE)
								VALUES
								(IN_CALLING,
								IN_PHONENUMBER,
								'l',
								0,
								TMP_MESSAGE,
								TMP_MESSAGE,
								SYSDATE(),
								'0',
								'0',
								IN_UNIQUECODE);
							else
								select 3;
								INSERT INTO EC_TBL_SHORTMESSAGE_smpp_tmp
								(OWNER,
								CALLER,
								ORGTYPE,
								ORGID,
								SMSMESSAGE,
								MESSAGE,
								CREATETIME,
								STATUS,
								OPERATORNO,
								UNIQUECODE)
								VALUES
								(IN_CALLING,
								IN_PHONENUMBER,
								'l',
								0,
								TMP_MESSAGE,
								TMP_MESSAGE,
								SYSDATE(),
								'0',
								'0',
								IN_UNIQUECODE);
							end if;
					
						set TMP_SENDCOUNT = ceil(TMP_LENGTH/65);

						update GJDX_SMSCOUNT
						set count_num = count_num - TMP_SENDCOUNT
						WHERE telephone = IN_PHONENUMBER AND is_valid = 'Y' and count_num > 0;
				END IF;
			end if;
		end if;
END;

