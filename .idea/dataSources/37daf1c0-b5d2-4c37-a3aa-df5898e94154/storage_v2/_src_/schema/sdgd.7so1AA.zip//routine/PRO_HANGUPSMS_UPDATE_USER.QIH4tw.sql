create
    definer = root@`%` procedure PRO_HANGUPSMS_UPDATE_USER(IN IN_FUNCTIONAL_ID varchar(20), IN IN_USER_ID varchar(20),
                                                           IN IN_USER_NAME varchar(30), IN IN_TELEPHONE varchar(30),
                                                           IN IN_MOBILE varchar(30), IN IN_COMP_NAME varchar(50),
                                                           IN IN_PRO_ID varchar(10), IN IN_USER_TYPE varchar(10),
                                                           IN IN_CUSTOMER_NAME varchar(50),
                                                           IN IN_CUSTOMER_TYPE varchar(10),
                                                           IN IN_USER_ADDRESS varchar(256), IN IN_BS_NAME varchar(50),
                                                           IN IN_BS_TEL varchar(30), IN IN_TAOCAN_NAME varchar(10),
                                                           IN IN_COST_TYPE varchar(10), OUT EXEC_RESULT varchar(20))
mdc:BEGIN
	
	 declare  TMP_COUNT int;
   declare  TMP_USER                  VARCHAR(20);
   declare TMP_DECRYPTIONUSERNAME    VARCHAR(30);
   declare TMP_DECRYPTIONPHONENYMBER VARCHAR(30);
   declare TMP_DECRYPTIONMOBILE      VARCHAR(30);
   declare TMP_USERTYPE              VARCHAR(10);
	 
	 
	 set TMP_USER                  = IN_USER_NAME;
   set TMP_USERTYPE              = '1';
   set TMP_DECRYPTIONUSERNAME    = IN_USER_NAME;
   set TMP_DECRYPTIONPHONENYMBER = IN_TELEPHONE;
   set TMP_DECRYPTIONMOBILE      = IN_MOBILE;
		
	
    -- 判断号码是否为11位，若不足11位则为固话号码（暂不考虑区号）
    if length(IN_USER_NAME) < 11 then
      set TMP_USERTYPE = '2';
    end if;
  
    INSERT INTO GJDX_TBL_UPDATE_USER
      (functionalid,
       userid,
       username,
       telephone,
       mobile,
       compname,
       proid,
       usertype,
       customername,
       customertype,
       useraddress,
       bsname,
       bstel,
       taocanname,
       costtype,
       createtime)
    VALUES
      (IN_FUNCTIONAL_ID,
       IN_USER_ID,
       TMP_DECRYPTIONUSERNAME,
       TMP_DECRYPTIONPHONENYMBER,
       TMP_DECRYPTIONMOBILE,
       IN_COMP_NAME,
       IN_PRO_ID,
       IN_USER_TYPE,
       IN_CUSTOMER_NAME,
       IN_CUSTOMER_TYPE,
       IN_USER_ADDRESS,
       IN_BS_NAME,
       IN_BS_TEL,
       IN_TAOCAN_NAME,
       IN_COST_TYPE,
       SYSDATE);
    COMMIT;
		
		 SELECT COUNT(*)
        INTO TMP_COUNT
        FROM GJDX_USER
       WHERE TELEPHONE = TMP_DECRYPTIONUSERNAME
         AND IS_VALID = 'Y';
      IF TMP_COUNT = 0 THEN
        set EXEC_RESULT = '1';
        leave mdc;
      END IF;
    
      -- 将用户更新的信息同步到用户的用户表
      UPDATE GJDX_USER
         SET TELEPHONE     = TMP_DECRYPTIONPHONENYMBER,
             MOBILE        = TMP_DECRYPTIONMOBILE,
             COMP_NAME     = IN_COMP_NAME,
             PRO_ID        = IN_PRO_ID,
             COMP_USER     = IN_CUSTOMER_NAME,
             CUSTOMER_TYPE = IN_CUSTOMER_TYPE,
             USER_ADDRESS  = IN_USER_ADDRESS,
             BS_NAME       = IN_BS_NAME,
             BS_TEL        = IN_BS_TEL,
             TAOCAN_NAME   = IN_TAOCAN_NAME,
             COST_TYPE     = IN_COST_TYPE
       WHERE USER_NAME = TMP_DECRYPTIONUSERNAME;

		
END;

