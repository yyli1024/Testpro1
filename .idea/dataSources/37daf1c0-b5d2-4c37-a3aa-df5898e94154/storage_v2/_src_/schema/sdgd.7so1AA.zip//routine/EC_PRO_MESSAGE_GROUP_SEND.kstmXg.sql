create
    definer = root@`%` procedure EC_PRO_MESSAGE_GROUP_SEND()
BEGIN
	#Routine body goes here...
     DECLARE  i             INT;
     DECLARE  TMP_OWNER     VARCHAR(20);
     DECLARE  TMP_MESSAGE   VARCHAR(512);
     DECLARE  done          INT DEFAULT 0;
     DECLARE C_MDC CURSOR FOR
     SELECT TELEPHONE  FROM gjdx_user WHERE substr(telephone,1,1) = '1' and LENGTH(telephone) = 11 and is_valid = 'Y';
     #SELECT TELEPHONE FROM HZH_TEST WHERE STATUS='Y'; 
     #SELECT TELEPHONE INTO TMP_OWNER FROM gjdx_user WHERE substr(telephone,1,1) = '1' and LENGTH(telephone) = 11 and is_valid = 'Y'; 
     DECLARE CONTINUE HANDLER FOR NOT FOUND SET done=1; 
     SET TMP_MESSAGE='山东联通挂机短信的自服务网址已更新，如需更新您的挂机短信内容，请登录新网址http://gjdx.17186.cn:8080/GJDX_SDQT 特此告知。';
     # SET i=0;
     	-- 打开游标  
	   OPEN C_MDC;
	-- 执行循环  
		  poaLoop:LOOP  
       
      IF DONE=1 THEN  
				LEAVE poaLoop; 
			END IF;

      FETCH  C_MDC INTO TMP_OWNER;
       	-- 判断是否结束循环  

       
      INSERT INTO EC_TBL_SHORTMESSAGE_SGIP_TMP
          (OWNER,
           CALLER,
           ORGTYPE,
           ORGID,
           SMSMESSAGE,
           MESSAGE,
           CREATETIME,
           STATUS,
           OPERATORNO,
           UNIQUECODE)
       VALUES
           ('106558000173',
            TMP_OWNER,
            'l',
             0,
            TMP_MESSAGE,
            TMP_MESSAGE,
            SYSDATE(),
            '0',
            '0',
            '225'); 
      # UPDATE HZH_TEST SET STATUS ='N' WHERE TELEPHONE=TMP_OWNER;
      # SET i = i + 1;

      /* IF i > 1000 THEN                   　　　　# 结束循环的条件: 当i大于10时跳出loop循环
          LEAVE poaLoop;
       END IF;
      	-- 取游标中的值  */
 
      END LOOP;
    -- 释放游标  
	 CLOSE C_MDC;
END;

