create
    definer = root@`%` procedure EC_PRO_INSERT_SMS_HESTORY(IN IN_SMSID varchar(100), IN IN_OWNER varchar(100),
                                                           IN IN_CALLER varchar(100), IN IN_ORGTYPE varchar(100),
                                                           IN IN_ORGID varchar(100), IN IN_SMSMESSAGE varchar(512),
                                                           IN IN_MESSAGE varchar(512), IN IN_CREATETIME varchar(30),
                                                           IN IN_STATUS varchar(10), IN IN_OPERATORNO varchar(10),
                                                           OUT EXEC_RESULT varchar(100))
BEGIN
	 /*  INSERT INTO EC_TBL_HESTORY_SMS
    VALUES
      (IN_SMSID,
       IN_OWNER,
       IN_CALLER,
       IN_ORGTYPE,
       IN_ORGID,
       IN_SMSMESSAGE,
       IN_MESSAGE,
       TO_DATE(IN_CREATETIME, 'YYYY/MM/DD HH24:MI:SS'),
       IN_STATUS,
       IN_OPERATORNO);*/
  
  
    set EXEC_RESULT = '0';
END;

