create
    definer = root@`%` procedure EC_PRO_UPDATE_COUNT(IN IN_SMSID varchar(30), IN IN_CALLER varchar(30),
                                                     IN IN_NETFLAG varchar(20), OUT EXEC_RESULT varchar(10))
mdc:BEGIN
		declare TMP_USERID               int;
    declare TMP_USERID_COUNT         int;
    declare TMP_TAOCANID             int;
    declare TMP_TAOCAN_MSG_MAX       int;
    declare TMP_TAOCAN_MSG_CNT       int;
    declare TMP_MAXMSG_COUNT         VARCHAR(20);
    declare TMP_OTHERNET_COUNT       VARCHAR(20);
    declare TMP_OTHERNET_UPDATE_TIME VARCHAR(20);
    declare TMP_IS_OUTSEND           VARCHAR(5);
    declare TMP_OWNER                VARCHAR(20);
    declare TMP_RESULT               VARCHAR(1);
    declare TMP_SEQ_NUMBER           int;
    declare TMP_OUT_COUNT            int;
    declare TMP_UNIQUE_SEQ           VARCHAR(20);
    declare TMP_ENCRYPTCALLER        varchar(30);
		
		
	  set TMP_ENCRYPTCALLER = IN_CALLER;
		-- lock tables EC_TBL_USER read
  
    SELECT COUNT(USER_ID)
      INTO TMP_USERID_COUNT
      FROM EC_TBL_USER
     WHERE TELEPHONE = TMP_ENCRYPTCALLER
       AND IS_VALID = 'Y';
  
    IF TMP_USERID_COUNT = 1 THEN
      SELECT USER_ID
        INTO TMP_USERID
        FROM EC_TBL_USER
       WHERE TELEPHONE = TMP_ENCRYPTCALLER
         AND IS_VALID = 'Y';
    ELSE
      DELETE from EC_TBL_SHORTMESSAGE_TMP WHERE SMSID = IN_SMSID;
      
      set EXEC_RESULT = '0';
      leave mdc;
    END IF;

    -- 判断当前用户本月是否还有短信条数
    select count_num
      into TMP_TAOCAN_MSG_CNT
      from GJDX_SMSCOUNT
     WHERE telephone = TMP_ENCRYPTCALLER;
	 select TMP_TAOCAN_MSG_CNT;
    IF TMP_TAOCAN_MSG_CNT > 0 THEN
      -- 本网
      IF IN_NETFLAG = 0 THEN
        INSERT INTO EC_TBL_SHORTMESSAGE(owner,caller,orgtype,orgid,smsmessage,message,createtime,status,operatorno,UNIQUECODE)
          SELECT OWNER,
                 CALLER,
                 '0',
                 ORGID,
                 '',
                 MESSAGE,
                 CREATETIME,
                 '0',
                 OPERATORNO,
                 UNIQUECODE
            FROM EC_TBL_SHORTMESSAGE_TMP
           WHERE SMSID = IN_SMSID;
      
        INSERT INTO EC_TBL_EXT_SHORTMESSAGE
        VALUES
          (IN_SMSID, IN_NETFLAG, '0', NULL, NULL, NULL, SYSDATE, NULL, '0');
      ELSE
        -- 异网   
        INSERT INTO EC_TBL_SHORTMESSAGE(owner,caller,orgtype,orgid,smsmessage,message,createtime,status,operatorno,UNIQUECODE)
          SELECT OWNER,
                 CALLER,
                 '0',
                 ORGID,
                 '',
                 MESSAGE,
                 CREATETIME,
                 '0',
                 OPERATORNO,
                 UNIQUECODE
            FROM EC_TBL_SHORTMESSAGE_TMP
           WHERE SMSID = IN_SMSID;
      
        INSERT INTO EC_TBL_EXT_SHORTMESSAGE
        VALUES
          (IN_SMSID, IN_NETFLAG, '0', NULL, NULL, NULL, SYSDATE(), NULL, '0');

      END IF;
      UPDATE EC_TBL_USER_SEND_COUNT
         SET IN_COUNT = IN_COUNT + 1
       WHERE USER_ID = TMP_USERID;
    
      update GJDX_SMSCOUNT
         set count_num = count_num - 1
       WHERE telephone = TMP_ENCRYPTCALLER;
    END IF;

    DELETE FROM EC_TBL_SHORTMESSAGE_TMP WHERE SMSID = IN_SMSID;

    set EXEC_RESULT = '0';
    leave mdc;
END;

