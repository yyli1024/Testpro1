create
    definer = root@`%` procedure EC_PRO_DELETE_POLICIES(IN IN_PID varchar(20), IN IN_PHONENUMBER varchar(30),
                                                        IN IN_STARTTIME varchar(30), IN IN_ENDTIME varchar(30),
                                                        IN IN_STATUS varchar(10), IN IN_CYCLEID varchar(20),
                                                        IN IN_MESSAGE varchar(1024), OUT EXEC_RESULT varchar(10))
BEGIN
	  declare TMP_COUNT  INT;
    declare TMP_USERID INT;
    declare TMP_ENCRYPTPHONENUMBER   varchar(30);
		 
	  set TMP_ENCRYPTPHONENUMBER = IN_PHONENUMBER;
    SELECT USERID
      INTO TMP_USERID
      FROM EC_TBL_USERINFO
     WHERE PHONENUMBER = TMP_ENCRYPTPHONENUMBER;
  
    DELETE FROM EC_TBL_POLICIES
     WHERE PID = IN_PID
       AND USERID = TMP_USERID;
  
    set EXEC_RESULT = '0';
END;

