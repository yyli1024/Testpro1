create definer = root@`%` trigger TRI_USERINFO_AUI2
    after delete
    on gjdx_user
    for each row
begin
DELETE from EC_TBL_USER WHERE USER_ID = OLD.USER_ID;
end;

