create
    definer = root@`%` procedure PRO_HANGUPSMS_ADD_PACKAGE(IN IN_FUNCTIONAL_ID varchar(20), IN IN_USER_ID varchar(10),
                                                           IN IN_USER_NAME varchar(30), IN IN_TELEPHONE varchar(30),
                                                           IN IN_IS_PACKEG varchar(20), IN IN_PACKAGE_ID varchar(10),
                                                           IN IN_PACKAGE_LOG varchar(10), OUT EXEC_RESULT varchar(20))
mdc:BEGIN
	 
	 declare TMP_COUNT        int;
   declare TMP_PACKAGECOUNT int; -- 闪信包中的短信条数
   declare TMP_USERNAME     varchar(20);
   declare TMP_PACKAGEID             int;
   declare TMP_PACKAGELOG            varchar(20);
   declare TMP_DECRYPTIONUSERNAME    varchar(30);
   declare TMP_DECRYPTIONPHONENYMBER varchar(30);
   declare TMP_USERTYPE              varchar(10);
	 
	 
	 set TMP_DECRYPTIONUSERNAME    = IN_USER_NAME;
   set TMP_DECRYPTIONPHONENYMBER = IN_TELEPHONE;
   set TMP_USERNAME              = IN_USER_NAME;
   set TMP_USERTYPE              = '1';
   set TMP_PACKAGEID  = TO_NUMBER(IN_PACKAGE_ID);
   set TMP_PACKAGELOG = IN_PACKAGE_LOG;
  
		
	
    -- 判断号码是否为11位，若不足11位则为固话号码（暂不考虑区号）
    if length(IN_USER_NAME) < 11 then
      set TMP_USERTYPE = '2';
    end if;
  
    INSERT INTO GJDX_TBL_CANCEL_USER
      (functionalid,
       userid,
       username,
       telephone,
       canceldate,
       isvalid,
       iseffective,
       createtime)
    VALUES
      (IN_FUNCTIONAL_ID,
       IN_USER_ID,
       TMP_DECRYPTIONUSERNAME,
       TMP_DECRYPTIONPHONENYMBER,
       IN_CANCEL_DATE,
       IN_EFFECTIVE,
       IN_ISVALID,
       SYSDATE);
		
		
		  SELECT COUNT(*)
        INTO TMP_COUNT
        FROM GJDX_USER
       WHERE TELEPHONE = TMP_DECRYPTIONUSERNAME
         AND IS_VALID = 'Y';
      IF TMP_COUNT = 0 THEN
        set EXEC_RESULT = '1';
        leave mdc;
      END IF;
    
      -- 判断修改套餐的时候是否加了叠加包
      if IN_PACKAGE_ID is not null then
        SELECT COUNT(*)
          INTO TMP_COUNT
          FROM GJDX_TAOCAN
         WHERE TAOCAN_ID = TMP_PACKAGEID
           AND IS_VALID = 'Y';
        if TMP_COUNT > 0 then
          -- 查询当前叠加包的条数信息
          SELECT MSG_COUNT
            INTO TMP_PACKAGECOUNT
            FROM GJDX_TAOCAN
           WHERE TAOCAN_ID = TMP_PACKAGEID
             AND IS_VALID = 'Y';
        
          INSERT INTO GJDX_TBL_USER_PACKAGE
            (USERPHONENUMBER,
             PACKAGE_ID,
             PACKAGE_LOG,
             IS_VALID,
             CREATETIME,
             IS_EFFECTIVE,
             NEXT_IS_VALID)
          VALUES
            (TMP_DECRYPTIONUSERNAME,
             IN_PACKAGE_ID,
             IN_PACKAGE_LOG,
             'Y',
             SYSDATE(),
             'Y',
             'Y');
						 
          update GJDX_SMSCOUNT
             set count_num = count_num + TMP_PACKAGECOUNT,
                 month_num = month_num + TMP_PACKAGECOUNT
           where IS_VALID = 'Y'
             and telephone = TMP_DECRYPTIONUSERNAME;

        else
          set EXEC_RESULT = 1;
          leave mdc;
        end if;
      end if;
		
END;

