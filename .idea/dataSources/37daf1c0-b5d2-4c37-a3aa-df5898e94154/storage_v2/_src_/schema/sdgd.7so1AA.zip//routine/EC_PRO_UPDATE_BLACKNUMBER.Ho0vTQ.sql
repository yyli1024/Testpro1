create
    definer = root@`%` procedure EC_PRO_UPDATE_BLACKNUMBER(IN IN_PHONENUMBER varchar(30), IN IN_BLACKNUMBER varchar(30),
                                                           IN IN_STATUS varchar(20), OUT EXEC_RESULT varchar(10))
mdc:BEGIN
		declare TMP_COUNT  int;
    declare TMP_USERID int;

    set EXEC_RESULT = '0';
    leave mdc;
END;

