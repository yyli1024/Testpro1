create
    definer = root@`%` procedure PRO_MOVE_CALLDATA()
mdc:BEGIN
	declare tmp_count          int;

	  SELECT COUNT(*)
    INTO TMP_COUNT
    FROM EC_TBL_CALLDATA_TMP A
   WHERE date_format(A.STARTTIME, '%Y-%m-%d') <=
         date_format((SYSDATE() - 1), '%Y-%m-%d');

  IF TMP_COUNT = 0 THEN
    leave mdc;
  END IF;

  INSERT INTO EC_TBL_CALLDATA
    (SELECT *
       FROM EC_TBL_CALLDATA_TMP
      WHERE date_format(STARTTIME, '%Y-%m-%d') <=
            date_format((SYSDATE - 1), '%Y-%m-%d'));

  DELETE from EC_TBL_CALLDATA_TMP
   WHERE date_format(STARTTIME, '%Y-%m-%d') <=
         date_format((SYSDATE - 1), '%Y-%m-%d');
END;

