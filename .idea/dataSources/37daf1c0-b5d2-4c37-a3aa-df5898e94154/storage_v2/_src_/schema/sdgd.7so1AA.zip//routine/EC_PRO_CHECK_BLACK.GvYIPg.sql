create
    definer = root@`%` procedure EC_PRO_CHECK_BLACK(IN IN_OWNER varchar(30), IN IN_CALLER varchar(30),
                                                    OUT EXEC_RESULT varchar(10))
mdc:BEGIN

		declare TMP_COUNT    int;
    declare TMP_IS_BLACK VARCHAR(5);
    declare TMP_ENCRYPTCALLING   varchar(30);
    declare TMP_ENCRYPTCALLED    varchar(30);
		
		
	  set TMP_ENCRYPTCALLING = IN_CALLER;
    set TMP_ENCRYPTCALLED  = IN_OWNER;
    SELECT COUNT(*)
      INTO TMP_COUNT
      FROM EC_TBL_BLACK_GLOBAL
     WHERE PHONE_NUMBER = TMP_ENCRYPTCALLED
       AND IS_VALID = 'Y';
  
    IF TMP_COUNT > 0 THEN
      set EXEC_RESULT = '1';
			leave mdc;
      -- RETURN;
    END IF;
  
    set TMP_COUNT = 0;
    SELECT COUNT(*)
      INTO TMP_COUNT
      FROM GJDX_BLACK
     WHERE telephone = TMP_ENCRYPTCALLED;
  
    IF TMP_COUNT > 0 THEN
      set EXEC_RESULT = '1';
			leave mdc;
      -- RETURN;
    END IF;
  
    set TMP_COUNT = 0;
    SELECT COUNT(*)
      INTO TMP_COUNT
      FROM GJDX_CLIENT A, EC_TBL_USER B
     WHERE A.USER_ID = B.USER_ID
       AND A.telephone = TMP_ENCRYPTCALLED
       AND B.TELEPHONE = TMP_ENCRYPTCALLING
       AND A.IS_VALID = 'N'
       AND B.IS_VALID = 'Y';
  
    IF TMP_COUNT = 0 THEN
      set EXEC_RESULT = '0';
			leave mdc;
			-- RETURN;
    ELSE
      set EXEC_RESULT = '1';
			leave mdc;
    END IF;

    set EXEC_RESULT = '0';
		leave mdc;
    -- RETURN;
END;

