create
    definer = root@`%` procedure PRO_CLEAR_COUNT(OUT EXEC_RESULT varchar(10))
mdc:BEGIN
	 UPDATE EC_TBL_USER_SEND_COUNT
     SET IN_COUNT = 0, OUT_COUNT = 0, LAST_CHECK = SYSDATE();
  COMMIT;
  set EXEC_RESULT = '0';
  leave mdc;
END;

