create
    definer = root@`%` procedure EC_PRO_SMS_FILTRATION(OUT EXEC_RESULT varchar(10))
mdc:BEGIN
	declare TMP_INDEX int;
	declare done int; 
	declare TMP_NETFLAG varchar(2);
	declare TMP_RESULT varchar(2);
	declare TMP_SMSID varchar(20);
	declare TMP_OWNER varchar(20);
	declare TMP_CALLER varchar(20);
	
	declare C_JOB CURSOR for SELECT SMSID, OWNER, CALLER FROM EC_TBL_SHORTMESSAGE_TMP WHERE SMSID > 0 ORDER BY SMSID ASC;
		 
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done=1; 
	-- 打开游标  
	open C_JOB;
	-- 执行循环  
		poaLoop:LOOP  
	-- 判断是否结束循环  
			-- set nflag = nflag + 1;
			IF done=1 THEN  
				LEAVE poaLoop; 
			END IF;

	-- 取游标中的值  
			FETCH  C_JOB into TMP_SMSID,TMP_OWNER,TMP_CALLER;
					CALL EC_PRO_CHECK_BLACK(TMP_OWNER,TMP_CALLER,TMP_RESULT);
					IF TMP_RESULT = '1' THEN
						DELETE FROM EC_TBL_SHORTMESSAGE_TMP WHERE SMSID = TMP_SMSID;
						leave mdc;
					END IF;
						
			CALL EC_PRO_CHECK_NET(TMP_OWNER, TMP_RESULT);
      set TMP_NETFLAG = TMP_RESULT;
    
      IF TMP_RESULT = '0' OR TMP_RESULT = '1' THEN
			select '3';
      CALL  EC_PRO_UPDATE_COUNT(TMP_SMSID,
                            TMP_CALLER,
                            TMP_NETFLAG,
                            TMP_RESULT);
      --  COMMIT;
      END IF;
			

			
			set TMP_SMSID = null;
			set TMP_OWNER = null;
			set TMP_CALLER = null;

      DELETE FROM EC_TBL_SHORTMESSAGE_TMP WHERE SMSID = TMP_SMSID;

			END LOOP poaLoop;  
	-- 释放游标  
	CLOSE C_JOB;  
END;

