create
    definer = root@`%` procedure PRO_HANGUPSMS_ADD_USER(IN IN_ACCOUNTNO varchar(50), IN IN_EXTNO varchar(20),
                                                        IN IN_PASSWORD varchar(30), IN IN_ID varchar(40),
                                                        IN IN_MOBILE varchar(20), IN IN_BUSINESS varchar(50),
                                                        IN IN_CONTENT varchar(1024), IN IN_COUNT varchar(10),
                                                        IN IN_PRODUCTID varchar(10), OUT EXEC_RESULT varchar(20))
mdc :
BEGIN
    declare TMP_SMSCOUNT int;
    -- 当月需要下发闪信总量
     declare TMP_MONTHCOUNT int;
    -- 下月需要下发的总量
     declare TMP_COUNT int;
    declare TMP_USERID int;
    -- 用户id
     declare TMP_PASSWD VARCHAR (20);
    declare TMP_FLAG VARCHAR (10);
    declare TMP_MSGCOUNT int;
    -- 本月套餐短信数量
     declare TMP_NEXTMSGCOUNT int;
    -- 下月套餐数量
     declare TMP_PACKAGECOUNT int;
    -- 叠加包的短信数量
     declare TMP_USER VARCHAR (20);
    declare TMP_TAOCANID int;
    declare TMP_NEXTTAOCANID int;
    declare TMP_PACKAGEID VARCHAR (20);
    declare TMP_PACKAGELOG VARCHAR (20);
    declare TMP_MOBILE VARCHAR (20);
    declare TMP_COMPNAME VARCHAR (50);
    declare TMP_GROUPID VARCHAR (20);
    declare TMP_GNFY VARCHAR (10);
    declare TMP_TAOCANJE VARCHAR (10);
    declare TMP_VALID VARCHAR (10);
    -- 是否立即生效（Y:立即生效，NM:下月神效）
     declare TMP_NEXT_IS_VALID VARCHAR (10);
    -- 下月的状态
     declare TMP_IS_VALID VARCHAR (10);
    -- 本月的状态
     declare TMP_SOURCE VARCHAR (10);
    -- 代理商编号
     declare TMP_STRATE_ID int;
    declare TMP_PSWDSHA VARCHAR (50);
    declare TMP_DECRYPTIONUSERNAME VARCHAR (30);
    declare TMP_DECRYPTIONPHONENYMBER VARCHAR (30);
    declare TMP_DECRYPTIONMOBILE VARCHAR (30);
    declare TMP_USERTYPE VARCHAR (4);
    -- 1为手机用户，2为固话用户
     declare TMP_MESSAGE VARCHAR (1024);
    declare TMP_AREAID VARCHAR (32);
    set TMP_COUNT = 0;
    set TMP_USERID = 0;
    set TMP_STRATE_ID = 0;
    set TMP_USERTYPE = '1';
    -- set TMP_TAOCANID              = IN_PRODUCTID + 0;
     set TMP_USER = IN_MOBILE;
    set TMP_COMPNAME = IN_ACCOUNTNO;
    set TMP_MOBILE = IN_MOBILE;
    set TMP_SOURCE = '281';
    -- 目前先用一个默认值用于演示
     set TMP_DECRYPTIONUSERNAME = IN_MOBILE;
    set TMP_DECRYPTIONPHONENYMBER = IN_MOBILE;
    set TMP_DECRYPTIONMOBILE = IN_MOBILE;
		set EXEC_RESULT = '0';
		
    -- 判断号码是否为11位，若不足11位则为固话号码（暂不考虑区号）
     /* if length(IN_USER_NAME) < 11 then
      set TMP_USERTYPE = '2';
    end if;*/
    -- SELECT SEQ_GJDX_USER.NEXTVAL INTO TMP_USERID FROM DUAL;
     -- 插入数据源基表中
     INSERT INTO GJDX_TBL_ADD_USER (
        accountno, extno, passwd, markid, mobile, business, content, count, productid, createtime
    )
    VALUES
        (
            IN_ACCOUNTNO, IN_EXTNO, IN_PASSWORD, IN_ID, IN_MOBILE, IN_BUSINESS, IN_CONTENT, IN_COUNT, IN_PRODUCTID, SYSDATE()
        );
    -- 手机用户
     if TMP_USERTYPE = '1'
    then -- 判断该用户是否是组的主号码
     select
        count(*) into tmp_count
    from
        GJDX_group_m
    where username = TMP_USER;
    -- 若是直接退出，不可再订购改业务
     if tmp_count > 0
    then set EXEC_RESULT = '1';
    leave mdc;
    end if;
    -- 判断该用户是否是挂机短信用户
     SELECT
        COUNT(*) INTO TMP_COUNT
    FROM
        GJDX_USER
    WHERE TELEPHONE = TMP_USER
        AND IS_VALID = 'Y';
    -- 若是直接退出
     IF TMP_COUNT > 0
    THEN set EXEC_RESULT = '2';
    leave mdc;
    END IF;
    SELECT
        COUNT(*) INTO TMP_COUNT
    FROM
        GJDX_TAOCAN
    WHERE msg_count = IN_COUNT
        AND IS_VALID = 'Y';
    IF TMP_COUNT = 0
    THEN set EXEC_RESULT = '3';
    leave mdc;
    else
    SELECT
        taocan_id INTO TMP_TAOCANID
    FROM
        GJDX_TAOCAN
    WHERE msg_count = IN_COUNT
        AND IS_VALID = 'Y';
    END IF;
    -- 判断这个套餐是否存在
     SELECT
        COUNT(*) INTO TMP_COUNT
    FROM
        GJDX_TAOCAN
    WHERE taocan_id = TMP_TAOCANID
        AND IS_VALID = 'Y';
    IF TMP_COUNT = 0
    THEN set EXEC_RESULT = '4';
    leave mdc;
    END IF;
    -- 若不是判断这个用户是开通用户还是复机用户
     -- 若是开通用户插入用户表
     -- if IN_FUNCTIONAL_ID = 'A' then
     -- 判断本月套餐ID是否有效
     -- 查询当前套餐的条数信息
     SELECT
        MSG_COUNT, TAOCAN_JE INTO TMP_MSGCOUNT, TMP_TAOCANJE
    FROM
        GJDX_TAOCAN
    WHERE TAOCAN_ID = TMP_TAOCANID
        AND IS_VALID = 'Y';
    set TMP_SMSCOUNT = TMP_MSGCOUNT;
    set TMP_GNFY = CONCAT(TMP_TAOCANJE, '00');
    -- 获取后台用户登录默认密码
     set TMP_PASSWD = '111111';
    set TMP_PSWDSHA = md5(md5(TMP_PASSWD));
    SELECT
        COUNT(*) into tmp_count
    FROM
        EC_TBL_NET
    WHERE net_number = left(TMP_USER, 7);
    if tmp_count > 0
    then
    SELECT
        areaid into tmp_areaid
    FROM
        EC_TBL_NET
    WHERE net_number = left(TMP_USER, 7);
    else set TMP_FLAG = left(TMP_USER, 1);
    if TMP_FLAG = 0
    then set tmp_areaid = left(TMP_USER, 4);
    else set tmp_areaid = '0531';
    end if;
    end if;
    -- 插入用户表
     INSERT INTO GJDX_USER (
        USER_NAME, TELEPHONE, REG_DATE, GROUP_ID, PARENT_ID, IS_LOCKED, IS_VALID, PASS_WORD, TAOCAN_ID, NEXT_TAOCAN_ID, PARTELEPHONE, QF_TAOCAN_ID, MOBILE, COMP_NAME, COMP_USER, SQ_MSG, HY_MSG, SOURCE, IS_GON, IS_DZ, GNFY, TONGBU, USER_NAME1, LOGIN_TYPE, PRO_ID, CUSTOMER_TYPE, USER_ADDRESS, BS_NAME, BS_TEL, TAOCAN_NAME, COST_TYPE, IS_EFFECTIVE, NEXT_IS_VALID, name, PWDMD5, STATUS_GJ, AREAID, next_isvalid
    )
    VALUES
        (
            TMP_USER, -- 手机号码
             TMP_USER, -- 手机号码
             sysdate(), 0, -- group表中字段
             0, 'N', 'Y', TMP_PASSWD, -- 手机后六位
             TMP_TAOCANID, -- 套餐id
             TMP_TAOCANID, -- 下一个taocanid
             TMP_USER, '0', -- 空
             TMP_USER, -- mobile
             TMP_COMPNAME, -- 公司名称
             TMP_COMPNAME, -- 公司
             '', '', TMP_SOURCE, 'Y', 'N', TMP_GNFY, 'Y', '', 'Y', '', '', '', '', '', '', '', '', '', TMP_USER, TMP_PSWDSHA, 'Y', tmp_areaid, '1'
        );
    select
        max(user_id) into TMP_USERID
    from
        GJDX_USER;
    if length(IN_CONTENT) < 1
    then set TMP_MESSAGE = '感谢您的来电。';
    else set TMP_MESSAGE = IN_CONTENT;
    end if;
    -- 插入号码池表中
     insert into EC_TBL_NUMBER_POOL (
        caller, operation, status, createtime
    )
    values
        (TMP_USER, 'O', '0', sysdate());
    -- 插入策略
     insert into GJDX_strate (
        thzt, fszq, contents, begin_date, end_date, user_id, is_audit, is_valid
    )
    values
        (
            '3', '1', TMP_MESSAGE, '00:00', '24:00', TMP_USERID, 'Y', 'Y'
        );
    select
        max(strate_id) into TMP_STRATE_ID
    from
        GJDX_strate;
    call ec_pro_add_policies (
        TMP_STRATE_ID, TMP_USER, '00:00', '24:00', '3', '1', TMP_MESSAGE, EXEC_RESULT
    );
    -- 根据用户的叠加包数来计算出需要本月需要下发的短信条数  
     -- 判断是否是正常用户并且是否订购叠加包
     -- if IN_USER_TYPE = 'U' AND IN_PACKAGE_ID is not null then
     /*  select count(*)
            into TMP_COUNT
            from GJDX_TAOCAN
           WHERE TAOCAN_ID = IN_PACKAGE_ID
             AND IS_VALID = 'Y';
          IF TMP_COUNT > 0 THEN
            select MSG_COUNT
              into TMP_PACKAGECOUNT
              from GJDX_TAOCAN
             WHERE TAOCAN_ID = IN_PACKAGE_ID
               AND IS_VALID = 'Y';
            -- 套餐数量加上叠加包数量
            set TMP_SMSCOUNT = TMP_SMSCOUNT + TMP_PACKAGECOUNT;
          
            set TMP_MONTHCOUNT = TMP_SMSCOUNT;
            -- 将用户订购的套餐信息放入用户套餐下发数量表中
            if TMP_VALID = 'Y' then
              set TMP_SMSCOUNT = 30;
            end if;*/
    set TMP_MONTHCOUNT = TMP_SMSCOUNT;
    select
        count(*) into TMP_COUNT
    from
        GJDX_SMSCOUNT
    where telephone = TMP_DECRYPTIONUSERNAME
        and IS_VALID = 'Y';
    if TMP_COUNT = 0
    then
    INSERT INTO GJDX_SMSCOUNT (
        TELEPHONE, COUNT_NUM, month_num, taocan_num, TAOCAN_TYPE, IS_VALID, IS_EFFECTIVE, NEXT_IS_VALID
    )
    VALUES
        (
            TMP_DECRYPTIONUSERNAME, TMP_SMSCOUNT, TMP_SMSCOUNT, TMP_SMSCOUNT, '1', 'Y', 'Y', 'Y'
        );
    end if;
    insert into ec_tbl_white_list (phonenumber)
    values
        (TMP_DECRYPTIONUSERNAME);
    insert into ec_tbl_OPEN_ACCOUNT_SYNC (phonenumber, status)
    values
        (TMP_DECRYPTIONUSERNAME, 'S');
        
    IF TRIM(TMP_DECRYPTIONUSERNAME) REGEXP "^[1][3456789][0-9]{9}$"
    THEN
    INSERT INTO ec_tbl_shortmessage_sgip (
        OWNER, caller, orgtype, orgid, smsmessage, message, createtime, STATUS, operatorno, UNIQUECODE
    )
    VALUES
        (
            TRIM(TMP_DECRYPTIONUSERNAME), '106558000173', 'l', '0', '尊敬的客户，您的挂机短信业务已开通，请登录PC端http://gjdx.17186.cn:8080/GJDX_SDQT 进行修改密码、编辑短信内容等操作。用户账号为开通挂短的手机号或固话号码，初始密码为6个1。感谢您的支持！', 'open', SYSDATE(), 0, 'open', 8
        );
    END IF;
        
    end if;
END;

