create definer = root@`%` trigger TRI_USERINFO_AUI
    after insert
    on gjdx_user
    for each row
begin
DECLARE TMP_COUNT int;
  set TMP_COUNT = 0;
      SELECT COUNT(*)
        INTO TMP_COUNT
        FROM EC_TBL_USER
       WHERE TELEPHONE = TRIM(NEW.TELEPHONE);

      IF TMP_COUNT > 0 THEN
        DELETE FROM EC_TBL_USER
         WHERE TELEPHONE = TRIM(NEW.TELEPHONE);
    
      END IF;
      INSERT INTO EC_TBL_USER
        (USER_ID,
         USER_NAME,
         TELEPHONE,
         IS_LOCKED,
         IS_VALID,
         TAOCAN_ID,
         IS_GON,
         BIND_PHONENUMBER,
         CREATETIME,
         UPDATETIME,
         PARENT_ID)
      VALUES
        (NEW.USER_ID,
         TRIM(NEW.USER_NAME),
         TRIM(NEW.TELEPHONE),
         NEW.IS_LOCKED,
         NEW.IS_VALID,
         NEW.TAOCAN_ID,
         NEW.IS_GON,
         NEW.MOBILE,
         NEW.REG_DATE,
         NEW.REG_DATE,
         NEW.PARENT_ID);
end;

