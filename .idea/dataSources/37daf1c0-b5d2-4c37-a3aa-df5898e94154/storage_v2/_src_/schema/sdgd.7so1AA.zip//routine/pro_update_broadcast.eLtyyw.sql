create
    definer = root@`'%'` procedure pro_update_broadcast(IN in_smsid int(20), IN in_status varchar(2))
mdc : 

BEGIN
	#Routine body goes here...
   DECLARE  TMP_OWNER          VARCHAR(20);
	 DECLARE  TMP_MESSAGE        VARCHAR(512);
	 DECLARE  TMP_COUNT          INT;

	IF in_smsid IS NULL OR in_smsid = 0 THEN
   LEAVE MDC;
  END IF;

   select count(*) into TMP_COUNT from broadcastmsg where smsid=in_smsid;
   IF TMP_COUNT= 0 THEN
		LEAVE MDC;
	 END IF;  
   
   select owner,message into TMP_OWNER,TMP_MESSAGE from broadcastmsg where smsid=in_smsid;
   delete from broadcastmsg where smsid=in_smsid;

		INSERT INTO EC_TBL_SHORTMESSAGE_sgip_tmp
									(OWNER,
									 CALLER,
									 ORGTYPE,
									 ORGID,
									 SMSMESSAGE,
									 MESSAGE,
									 CREATETIME,
									 STATUS,
									 OPERATORNO,
									 UNIQUECODE)
								VALUES
									('106558000173',
									 TMP_OWNER,
									 'l',
									 0,
									 TMP_MESSAGE,
									 TMP_MESSAGE,
									 SYSDATE(),
									 '0',
									 '0',
									 '225');
END;

