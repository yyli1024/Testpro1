create
    definer = root@`%` procedure PRO_CLEAN_SGIP_SMS(IN in_smsid int(20))
mdc:BEGIN


   declare temp_smsid        int (10);
   declare temp_owner        VARCHAR(20);
   declare temp_caller       VARCHAR (20);
   declare temp_orgtype      CHAR(1);
   declare temp_orgid        int(10);
   declare temp_smsmessage   VARCHAR(128);
   declare temp_message      VARCHAR(1024);
   declare temp_createtime   DATE;
   declare temp_status       CHAR (1);
   declare temp_operatorno   VARCHAR(20);
   declare temp_uniquecode   int(10);
   declare done              int(10);
	 
	 declare c_emp CURSOR for select  * FROM EC_TBL_SHORTMESSAGE WHERE smsid < in_smsid;
	 DECLARE CONTINUE HANDLER FOR NOT FOUND SET done=1; 

	IF in_smsid IS NULL OR in_smsid = 0
	THEN
		leave mdc;
	END IF;

	OPEN c_emp;
		poaLoop:LOOP

		-- 判断是否结束循环  
		IF done=1 THEN  
			LEAVE poaLoop; 
		END IF;

		FETCH c_emp
		INTO temp_smsid, temp_owner, temp_caller, temp_orgtype, temp_orgid,
		temp_smsmessage, temp_message, temp_createtime, temp_status,
		temp_operatorno,temp_uniquecode;

		set temp_status = '1';                          -- this means submit ok

		INSERT INTO EC_TBL_HESTORY_SMS
		VALUES (temp_smsid, Data_Encryption(temp_owner), Data_Encryption(temp_caller), temp_orgtype,
			 temp_orgid, temp_smsmessage, temp_message,
			 temp_createtime, temp_status, temp_operatorno);

		INSERT INTO EC_TBL_HESTORY_SMS_TMP
		VALUES (temp_smsid, Data_Encryption(temp_owner), Data_Encryption(temp_caller), temp_orgtype,
		temp_orgid, temp_smsmessage, temp_message, temp_createtime,
		temp_status, temp_operatorno,temp_uniquecode);


		DELETE from EC_TBL_SHORTMESSAGE
		WHERE smsid = temp_smsid;

		END LOOP;
	CLOSE c_emp;
	leave mdc;
END;

