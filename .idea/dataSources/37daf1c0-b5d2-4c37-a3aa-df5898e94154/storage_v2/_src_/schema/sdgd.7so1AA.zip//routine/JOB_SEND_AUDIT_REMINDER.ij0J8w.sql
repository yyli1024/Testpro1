create
    definer = root@`%` procedure JOB_SEND_AUDIT_REMINDER()
mdc:BEGIN
	declare tmp_count          int;
  declare tmp_count_care     int;
  declare tmp_count_spread   int;
  declare tmp_count_policies int;
  declare tmp_count_group    int;
  declare tmp_timecount     int;

  declare TMP_MESSAGE          VARCHAR(1024);
  declare TMP_MESSAGE_CARE     VARCHAR(256);
  declare TMP_MESSAGE_SPREAD   VARCHAR(256);
  declare TMP_MESSAGE_POLICIES VARCHAR(256);
  declare TMP_MESSAGE_GROUP    VARCHAR(256);

  
   set TMP_MESSAGE = '【挂机短信平台】：';
  -- 关怀短信审核
  select count(*)
    into tmp_count_care
    from EC_TBL_CARE
   where is_valid = 'S';
  if tmp_count_care > 0 then
    set TMP_MESSAGE_CARE = CONCAT('关怀短信审核中有',tmp_count_care,'条尚未审核,');
    set TMP_MESSAGE      = CONCAT(TMP_MESSAGE,TMP_MESSAGE_CARE);
  end if;
  -- 推广短信审核
  select count(*)
    into tmp_count_spread
    from ec_tbl_spread
   where is_valid = 'S';
  if tmp_count_spread > 0 then
    set TMP_MESSAGE_SPREAD = CONCAT('推广短信审核中有',tmp_count_spread,'条尚未审核,');
    set TMP_MESSAGE       = CONCAT(TMP_MESSAGE ,TMP_MESSAGE_SPREAD);
  end if;
  -- 策略内容审核
  select count(*)
    into tmp_count_policies
    from EC_TBL_POLICIES_tmp
   where is_valid = 'S';
  if tmp_count_policies > 0 then
    set TMP_MESSAGE_POLICIES = CONCAT('策略短信审核中有',tmp_count_policies,'条尚未审核,');
    set TMP_MESSAGE          = CONCAT(TMP_MESSAGE,TMP_MESSAGE_POLICIES);
  end if;
  -- 群组策略审核
  select count(*)
    into tmp_count_group
    from ec_tbl_policies_group
   where is_valid = 'S';
  if tmp_count_group > 0 then
    set TMP_MESSAGE_GROUP = CONCAT('群组短信审核中有',tmp_count_group,'条尚未审核,');
    set TMP_MESSAGE       = CONCAT(TMP_MESSAGE,TMP_MESSAGE_GROUP);
  end if;

  set tmp_count = tmp_count_care + tmp_count_spread + tmp_count_policies +
               tmp_count_group;

  -- 早8点到晚8点直接发送审核提醒
   select count(*) into tmp_timecount from dual where to_number(to_char(sysdate,'hh24'))>8 and to_number(to_char(sysdate,'hh24'))<20;
   
  if tmp_count > 0 and tmp_timecount > 0 then
    set TMP_MESSAGE = CONCAT(TMP_MESSAGE,'望尽快审核。');
    INSERT INTO EC_TBL_SHORTMESSAGE
      (SMSID,
       OWNER,
       CALLER,
       ORGTYPE,
       ORGID,
       SMSMESSAGE,
       MESSAGE,
       CREATETIME,
       STATUS,
       OPERATORNO)
    VALUES
      (EC_SEQ_SMS_TMP.NEXTVAL,
       '******',
       '******',
       '0',
       '2',
       '',
       TMP_MESSAGE,
       sysdate,
       '0',
       '0');
  end if;
END;

