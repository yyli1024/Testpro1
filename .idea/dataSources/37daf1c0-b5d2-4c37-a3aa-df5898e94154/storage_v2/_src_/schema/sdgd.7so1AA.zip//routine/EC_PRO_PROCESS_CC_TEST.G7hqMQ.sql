create
    definer = root@`%` procedure EC_PRO_PROCESS_CC_TEST(IN IN_CALLING varchar(30), IN IN_CALLED varchar(30),
                                                        IN IN_PHONENUMBER varchar(30),
                                                        IN IN_CALLFAILREASEON varchar(10), OUT EXEC_RESULT varchar(10))
mdc:BEGIN

    declare TMP_STARTTIME        varchar(30);
		declare TMP_ENDTIME          varchar(30);
		
		set TMP_STARTTIME = date_format(sysdate(),"%Y%m%d%H%i%s");
		set TMP_ENDTIME = date_format(sysdate(),"%Y%m%d%H%i%s");
		
	 insert into ec_tbl_calldata_original(calling,called,phonenumber,starttime,endtime,callfailreason)  values(IN_CALLING,IN_CALLED,IN_PHONENUMBER,TMP_STARTTIME,TMP_ENDTIME,IN_CALLFAILREASEON);
  
  
    set EXEC_RESULT := '0';
		leave mdc;
END;

