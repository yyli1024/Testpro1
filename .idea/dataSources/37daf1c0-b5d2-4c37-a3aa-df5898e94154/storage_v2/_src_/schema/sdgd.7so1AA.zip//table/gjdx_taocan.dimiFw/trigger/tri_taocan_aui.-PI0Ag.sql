create definer = root@`%` trigger TRI_TAOCAN_AUI
    after insert
    on gjdx_taocan
    for each row
    INSERT INTO EC_TBL_TAOCAN
        (TAOCAN_ID,
         TAOCAN_JE,
         MSG_COUNT,
         C_ZF,
         IS_VALID,
         TAOCAN_NAME,
         IS_HID)
      VALUES
        (NEW.TAOCAN_ID,
         NEW.TAOCAN_JE,
         NEW.MSG_COUNT,
         NEW.C_ZF,
         NEW.IS_VALID,
         NEW.TAOCAN_NAME,
         NEW.IS_HID);

