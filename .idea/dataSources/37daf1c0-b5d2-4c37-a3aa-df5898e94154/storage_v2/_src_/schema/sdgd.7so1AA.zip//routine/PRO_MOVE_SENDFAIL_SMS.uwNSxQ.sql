create
    definer = root@`%` procedure PRO_MOVE_SENDFAIL_SMS()
mdc:BEGIN
	declare tmp_count          int;

  SELECT COUNT(*)
    INTO tmp_count
    FROM EC_TBL_SHORTMESSAGE A
   WHERE date_format(A.CREATETIME, '%Y-%m-%d') <=
         date_format((SYSDATE - 1), '%Y-%m-%d');

  IF tmp_count > 0 THEN
    DELETE from EC_TBL_SHORTMESSAGE
     WHERE date_format(CREATETIME, '%Y-%m-%d') <=
           date_format((SYSDATE - 1), '%Y-%m-%d');
  END IF;

  set tmp_count = 0;

  SELECT COUNT(*)
    INTO tmp_count
    FROM EC_TBL_SHORTMESSAGE_TMP A
   WHERE date_format(A.CREATETIME, '%Y-%m-%d') <=
         date_format((SYSDATE - 1), '%Y-%m-%d');

  IF tmp_count > 0 THEN
    DELETE from EC_TBL_SHORTMESSAGE_TMP
     WHERE date_format(CREATETIME, '%Y-%m-%d') <=
           date_format((SYSDATE - 1), '%Y-%m-%d');
  END IF;
END;

