create definer = root@`%` trigger TRI_TAOCAN_AUI2
    after delete
    on gjdx_taocan
    for each row
begin
 DELETE from EC_TBL_TAOCAN WHERE TAOCAN_ID = old.taocan_id;
end;

