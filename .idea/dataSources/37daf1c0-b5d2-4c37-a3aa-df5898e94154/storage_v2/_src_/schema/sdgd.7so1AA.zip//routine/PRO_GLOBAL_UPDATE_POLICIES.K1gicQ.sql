create
    definer = root@`%` procedure PRO_GLOBAL_UPDATE_POLICIES(IN IN_PID varchar(20), OUT EXEC_RESULT varchar(20))
mdc:BEGIN
	declare  V_ERR_NUM     int;
  declare V_ERR_MSG     VARCHAR(100);
  declare TMP_CYCLEID   VARCHAR(20);
  declare TMP_MESSGAGE  VARCHAR(512);
  declare TMP_STARTTIME VARCHAR(20);
  declare TMP_ENDTIME   VARCHAR(20);
  declare TMP_STATUS    VARCHAR(10);
  declare TMP_TALLY     VARCHAR(10);
  declare TMP_USERID VARCHAR(20);
  declare TMP_GROUP_ID VARCHAR(20);
	declare done int; 
  declare cur_test CURSOR for SELECT USER_ID FROM GJDX_USER WHERE GROUP_ID = TMP_GROUP_ID AND USER_ID <> TMP_USERID AND IS_VALID = 'Y';
	
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done=1; 
		 
	SELECT CYCLEID,
         MESSAGE,
         STARTTIME,
         ENDTIME,
         STATUS,
         TALLY,
         USERID,
         GROUP_ID
    INTO TMP_CYCLEID,
         TMP_MESSGAGE,
         TMP_STARTTIME,
         TMP_ENDTIME,
         TMP_STATUS,
         TMP_TALLY,
         TMP_USERID,
         TMP_GROUP_ID
    FROM EC_TBL_POLICIES_GROUP A
   WHERE PID = IN_PID;
	 
		open cur_test;
    mdcloop:LOOP

		FETCH  cur_test into TMP_USERID;
		
    IF TMP_USERID IS NULL THEN
      leave mdc;
      set EXEC_RESULT = 0;
    END IF;
  
    -- 统一添加策略先删除服务号码对应group_ID下的业务号码USER_ID
    DELETE FROM EC_TBL_POLICIES
     WHERE USERID = TMP_USERID
       AND IS_VALID = 'Y';
    set EXEC_RESULT = 0;
    -- 批量更新业务号码的策略；
    INSERT INTO EC_TBL_POLICIES
      (PID,
       USERID,
       CYCLEID,
       STATUS,
       MESSAGE,
       STARTTIME,
       ENDTIME,
       IS_VALID,
       IS_STOP,
       TALLY)
    VALUES
      (SEQ_GJDX_STRA.NEXTVAL,
       MDC.USER_ID,
       TMP_CYCLEID,
       TMP_STATUS,
       TMP_MESSGAGE,
       TMP_STARTTIME,
       TMP_ENDTIME,
       'Y',
       'N',
       TMP_TALLY);
    set EXEC_RESULT = 0;
  END LOOP;
	close cur_test;
  set EXEC_RESULT = 0;
END;

