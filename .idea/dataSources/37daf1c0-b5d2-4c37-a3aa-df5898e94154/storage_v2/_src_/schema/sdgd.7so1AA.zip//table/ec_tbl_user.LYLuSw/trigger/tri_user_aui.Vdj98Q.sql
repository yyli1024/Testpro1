create definer = root@`%` trigger TRI_USER_AUI
    after insert
    on ec_tbl_user
    for each row
begin
  DECLARE TMP_COUNT  int;
  DECLARE TMP_STATUS CHAR(1);
  DECLARE TMP_COUNT1 int;
	
	IF UPPER(NEW.IS_VALID) = 'Y' THEN
    set TMP_STATUS = '1';
  ELSE
    set TMP_STATUS = '0';
  END IF;
	
	 set TMP_COUNT = 0;
      SELECT COUNT(*)
        INTO TMP_COUNT
        FROM EC_TBL_USERINFO
       WHERE PHONENUMBER = NEW.TELEPHONE;

      IF TMP_COUNT > 0 THEN
        UPDATE EC_TBL_USERINFO
           SET USERID     = NEW.USER_ID,
               STATUS     = TMP_STATUS,
               UPDATETIME = SYSDATE()
         WHERE PHONENUMBER = NEW.TELEPHONE;
      ELSE
        INSERT INTO EC_TBL_USERINFO
        VALUES
          (NEW.USER_ID, NEW.TELEPHONE, TMP_STATUS, SYSDATE(), SYSDATE());
      END IF;

      SELECT COUNT(*)
        INTO TMP_COUNT1
        FROM EC_TBL_SMSCOUNT
       WHERE PHONENUMBER = NEW.TELEPHONE;
      IF TMP_COUNT1 = 0 THEN
        INSERT INTO EC_TBL_SMSCOUNT VALUES (NEW.TELEPHONE, 0, 0, 0);
      END IF;

      INSERT INTO EC_TBL_USER_SEND_COUNT
        (USER_ID,
         TAOCAN_ID,
         IN_COUNT,
         IS_OUTSEND,
         OUT_COUNT,
         STATUS,
         REMARK,
         STATUS1,
         STATUS2,
         STATUS3,
         LAST_CHECK)
      VALUES
        (NEW.USER_ID,
         NEW.TAOCAN_ID,
         0,
         NEW.IS_GON,
         0,
         '0',
         NULL,
         NULL,
         NULL,
         NULL,
         SYSDATE());
end;

