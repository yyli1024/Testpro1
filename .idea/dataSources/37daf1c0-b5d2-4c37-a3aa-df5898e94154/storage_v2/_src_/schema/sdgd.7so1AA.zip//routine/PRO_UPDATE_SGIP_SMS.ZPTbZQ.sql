create
    definer = root@`%` procedure PRO_UPDATE_SGIP_SMS(IN IN_SMSID int(20), IN IN_STATUS varchar(10),
                                                     IN IN_SMSMESSAGE varchar(1024), IN IN_SYSTEMID int(20))
mdc:BEGIN
		
	declare TEMP_SMSID      int(10);
  declare TEMP_OWNER      VARCHAR(20);
  declare TEMP_CALLER     VARCHAR(20);
  declare TEMP_ORGTYPE    CHAR(1);
  declare TEMP_ORGID      int(10);
  declare TEMP_SMSMESSAGE VARCHAR(256);
  declare TEMP_MESSAGE    VARCHAR(1024);
  declare TEMP_CREATETIME DATE;
  declare TEMP_STATUS     CHAR(1);
  declare TEMP_OPERATORNO VARCHAR(20);
  declare TEMP_NETFLAG    int(10);
  declare TEMP_TAOCAN     int(10);
  declare TEMP_UNIQUECODE int(10);
		
	 IF IN_SMSID IS NULL OR IN_SMSID = 0 THEN
    leave mdc;
  END IF;

    SELECT SMSID,
           OWNER,
           CALLER,
           ORGTYPE,
           ORGID,
           SMSMESSAGE,
           MESSAGE,
           CREATETIME,
           STATUS,
           OPERATORNO,
           UNIQUECODE
      INTO TEMP_SMSID,
           TEMP_OWNER,
           TEMP_CALLER,
           TEMP_ORGTYPE,
           TEMP_ORGID,
           TEMP_SMSMESSAGE,
           TEMP_MESSAGE,
           TEMP_CREATETIME,
           TEMP_STATUS,
           TEMP_OPERATORNO,
           TEMP_UNIQUECODE
      FROM EC_TBL_SHORTMESSAGE
     WHERE SMSID = IN_SMSID;
  
    -- 测试短信不入历史表和话单表 add by zhoucanyu 20151117
    IF TEMP_OWNER = '1863517898' THEN
      DELETE from EC_TBL_SHORTMESSAGE WHERE SMSID = IN_SMSID;
      leave mdc;
    END IF;
  

    IF IN_STATUS IS NOT NULL THEN
      set TEMP_STATUS = IN_STATUS;
    END IF;
  
	
    INSERT INTO EC_TBL_HESTORY_SMS
    VALUES
      (TEMP_SMSID,
       Data_Encryption(TEMP_OWNER),
       Data_Encryption(TEMP_CALLER),
       TEMP_ORGTYPE,
       TEMP_ORGID,
       TEMP_SMSMESSAGE,
       TEMP_MESSAGE,
       TEMP_CREATETIME,
       TEMP_STATUS,
       TEMP_OPERATORNO);
  
    IF TEMP_STATUS = '1' THEN
      INSERT INTO EC_TBL_HESTORY_SMS_TMP
      VALUES
        (TEMP_SMSID,
         Data_Encryption(TEMP_OWNER),
         Data_Encryption(TEMP_CALLER),
         TEMP_ORGTYPE,
         TEMP_ORGID,
         TEMP_SMSMESSAGE,
         TEMP_MESSAGE,
         TEMP_CREATETIME,
         TEMP_STATUS,
         TEMP_OPERATORNO,
         TEMP_UNIQUECODE);
    END IF;
  
    UPDATE EC_TBL_EXT_SHORTMESSAGE
       SET RESULT = '1'
     WHERE SMSID = TEMP_SMSID;



    DELETE from  EC_TBL_SHORTMESSAGE WHERE SMSID = IN_SMSID;
  

    IF IN_SYSTEMID <> -1 THEN
      INSERT INTO EC_TBL_SYSTEMIDTABLE
      VALUES
        (IN_SMSID, IN_SYSTEMID, SYSDATE);
    END IF;
		
END;

