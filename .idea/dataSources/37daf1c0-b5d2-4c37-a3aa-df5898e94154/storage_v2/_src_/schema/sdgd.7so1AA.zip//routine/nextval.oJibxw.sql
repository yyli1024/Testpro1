create
    definer = root@`%` function nextval(str varchar(50)) returns int
begin
	declare i int;
	set i=(select start_value from mysql_seq where name=str);
	update mysql_seq
		set start_value=i+increment_value
	where name=str;
return i;
end;

