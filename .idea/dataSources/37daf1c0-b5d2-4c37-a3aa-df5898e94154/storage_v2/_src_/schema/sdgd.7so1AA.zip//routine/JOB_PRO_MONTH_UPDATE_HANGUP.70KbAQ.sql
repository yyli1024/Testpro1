create
    definer = root@`%` procedure JOB_PRO_MONTH_UPDATE_HANGUP()
mdc:BEGIN
	declare tmp_count          int;

	-- 判断当前用户是否是下月生效，若是下月生效则将用户的下月信息更新
  -- GJDX_SMSCOUNT
  -- GJDX_TBL_USER_PACKAGE
  -- GJDX_USER
  -- 将下月生效用户的下月状态更新到本月状态上并且将下月是否生效的状态更新成当前生效的状态
  -- 判断GJDX_SMSCOUNT这个用户里面下月生效的
  select count(*) into tmp_count from GJDX_SMSCOUNT where is_valid = 'N' and is_effective = 'Y';
  if tmp_count > 0 then
    update GJDX_SMSCOUNT set is_valid = next_is_valid,is_effective = 'N' where is_valid =  'N' and is_effective = 'Y';
    commit;
  end if;
  
  -- 判断GJDX_TBL_USER_PACKAGE这个用户里面下月生效的
  select count(*) into tmp_count from GJDX_TBL_USER_PACKAGE where is_valid = 'N'  and is_effective = 'Y';
  if tmp_count > 0 then
    update GJDX_TBL_USER_PACKAGE set is_valid = next_is_valid,is_effective = 'N',createtime = sysdate() where is_valid = 'N' and is_effective = 'Y';
    commit;
  end if;
  
   -- 判断GJDX_USER这个用户里面下月生效的
  select count(*) into tmp_count from GJDX_USER where is_valid =  'N'  and is_effective = 'Y';
  if tmp_count > 0 then
    update GJDX_USER set is_valid = next_is_valid,is_effective = 'N' where is_valid = 'N' and is_effective = 'Y';
    commit;
  end if;
  
  -- 将用户的下个月套餐号码更新到当前套餐上
  update GJDX_USER set taocan_id = next_taocan_id where is_valid = 'Y';
  commit;
  
  
  -- 如果是刚开始就订购下月生效的用户本月有免费的30条本网短信，所以需要重新计算一下下月的套餐数量
  
  update GJDX_SMSCOUNT set count_num = month_num where is_valid = 'Y';
  commit;
  
  update GJDX_SMSCOUNT set month_num = taocan_num where is_valid = 'Y';
  commit;
  
  
  -- 将叠加包中的所有信息全部都置于失效状态，除非本月生效的叠加包信息
  update GJDX_TBL_USER_PACKAGE set is_valid = 'N' ,is_effective = 'N',next_is_valid = 'N' where to_char(createtime,'%Y%M') < to_char(sysdate(),'%Y%M');
  commit;
  
  leave mdc;
END;

