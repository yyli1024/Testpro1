create
    definer = root@`%` procedure JOB_SEND_CARE_SMS()
mdc:BEGIN
	declare tmp_count    int;
  declare tmp_groupid  varchar(20);
  declare tmp_userid   varchar(20);
  declare TMP_caller   VARCHAR(20);
  declare TMP_called   VARCHAR(20);
  declare TMP_MESSAGE  VARCHAR(1024);
  declare TMP_MESSAGE1 VARCHAR(1024);
  declare TMP_MESSAGE2 VARCHAR(1024);
  declare tmp_tally    varchar(10);
  declare tmp_date     date;
  declare tmp_sendtime varchar(20);
  declare tmp_smscount int;
	declare birthdaydone int; 
	declare holidaydone int; 
	declare clientdone1 int; 
	declare clientdone2 int; 

	 -- 游标获取客户组资料中生日是今天的用户信息
  declare c_GJDX_client CURSOR for 
    select telephone
      from GJDX_Client
     where group_id = tmp_groupid
       and user_id = tmp_userid
       and birthday = 'Y'
       and date_format(birthdaytime, '%Y%M%D') = date_format(sysdate(), '%Y%M%D')
       and is_valid = 'Y';

  -- 游标获取客户组资料需要下发节日信息的用户信息     
  declare c_GJDX_client1 CURSOR for 
    select telephone
      from GJDX_Client
     where group_id = tmp_groupid
       and user_id = tmp_userid
       and is_valid = 'Y';

  -- 游标获取需要下发生日的用户的客户信息
  declare c_birthday CURSOR for 
    select group_id, userid, telephone, tally, message
      from EC_TBL_CARE
     where care_type = '1'
    --    and substr(starttime,1,instr(starttime,':',-1)-1) = 
    --       to_char(sysdate(), '%H')
       and is_valid = 'Y';

  -- 游标获取需要下发节日的用户的客户信息    
  declare c_holiday CURSOR for 
    select group_id, userid, telephone, tally, message
      from EC_TBL_CARE
     where care_type = '2'
       and date_format(str_to_date(solartime, '%y%m%d'), '%y%m%d') =
           date_format(sysdate(), '%y%m%d')
     --  and substr(starttime,1,instr(starttime,':',-1)-1) = 
     --      to_char(sysdate(), '%H')
       and is_valid = 'Y';
BEGIN
	 DECLARE CONTINUE HANDLER FOR NOT FOUND SET birthdaydone=1,holidaydone=1; 
	
	-- DECLARE CONTINUE HANDLER FOR NOT FOUND SET holidaydone=1; 
  -- 生日
	
  -- 根据当前时间查询出来需要今天发送的整个关怀表的所有短信
	
	-- 打开游标  
	open c_birthday;
	-- 执行循环  
		birthdayLoop:LOOP  
	-- 判断是否结束循环  
			-- set nflag = nflag + 1;
			IF birthdaydone=1 THEN  
				LEAVE birthdayLoop; 
			END IF;
	-- 取游标中的值  
		FETCH	c_birthday
    INTO tmp_groupid, tmp_userid, TMP_caller, tmp_tally, TMP_MESSAGE;
			  -- 查询该用户是否可以下发关怀短信，若不可以直接下一个号码
    select count(*)
      into tmp_count
      from GJDX_USER
     where is_valid = 'Y'
       and status_gh = 'Y'
       and user_name = TMP_caller;
    if tmp_count = 0 then
      -- continue;
			iterate birthdayLoop;
    end if;
		
    OPEN c_GJDX_client;
		
		clientLoop1:LOOP  
	-- 判断是否结束循环  
			-- set nflag = nflag + 1;
			IF clientdone1=1 THEN  
				LEAVE clientLoop1; 
			END IF;
    FETCH c_GJDX_client
      INTO TMP_called;
   -- WHILE c_GJDX_client%FOUND LOOP
      begin
        -- 查询生日短信是否要拆分开
        -- 不需要拆分
        IF tmp_tally = '1' THEN
          select count_num
            into tmp_smscount
            from GJDX_SMSCOUNT
           where telephone = TMP_caller;
          if tmp_smscount > 0 then
            INSERT INTO EC_TBL_SHORTMESSAGE
              (SMSID,
               OWNER,
               CALLER,
               ORGTYPE,
               ORGID,
               SMSMESSAGE,
               MESSAGE,
               CREATETIME,
               STATUS,
               OPERATORNO)
            VALUES
              (EC_SEQ_SMS_TMP.NEXTVAL,
               TMP_called,
               TMP_caller,
               '0',
               '0',
               '',
               TMP_MESSAGE,
               sysdate(),
               '0',
               'GH');
          
            UPDATE EC_TBL_USER_SEND_COUNT
               SET IN_COUNT = IN_COUNT + 1
             WHERE USER_ID = tmp_userid;
          
            update GJDX_SMSCOUNT
               set count_num = count_num - 1
             WHERE telephone = TMP_CALLER;
          end if;
          -- 需要拆分
        ELSeIF tmp_tally = '2' THEN
          select count_num
            into tmp_smscount
            from GJDX_SMSCOUNT
           where telephone = TMP_caller;
        
          if tmp_smscount > 1 then
            -- 65个字符一组
            SELECT SUBSTR(TMP_MESSAGE, 0, 65) into TMP_MESSAGE1 FROM DUAL;
          
            INSERT INTO EC_TBL_SHORTMESSAGE
              (SMSID,
               OWNER,
               CALLER,
               ORGTYPE,
               ORGID,
               SMSMESSAGE,
               MESSAGE,
               CREATETIME,
               STATUS,
               OPERATORNO)
            VALUES
              (EC_SEQ_SMS_TMP.NEXTVAL,
               TMP_CALLEd,
               TMP_caller,
               '0',
               '0',
               '',
               TMP_MESSAGE1,
               sysdate(),
               '0',
               'GH');
          
            SELECT SUBSTR(TMP_MESSAGE, 66) into TMP_MESSAGE2 FROM DUAL;
            INSERT INTO EC_TBL_SHORTMESSAGE
              (SMSID,
               OWNER,
               CALLER,
               ORGTYPE,
               ORGID,
               SMSMESSAGE,
               MESSAGE,
               CREATETIME,
               STATUS,
               OPERATORNO)
            VALUES
              (EC_SEQ_SMS_TMP.NEXTVAL,
               TMP_CALLEd,
               TMP_caller,
               '0',
               '0',
               '',
               TMP_MESSAGE2,
               sysdate(),
               '0',
               'GH');
          
            -- 条数计费
            UPDATE EC_TBL_USER_SEND_COUNT
               SET IN_COUNT = IN_COUNT + 2
             WHERE USER_ID = tmp_userid;
          
            update GJDX_SMSCOUNT
               set count_num = count_num - 2
             WHERE telephone = TMP_CALLER;
          end if;
        END IF;
			end;
    END LOOP clientLoop1;
    CLOSE c_GJDX_client;
  END LOOP birthdayLoop;
		-- END LOOP birthdayLoop;  
	-- 释放游标  
	CLOSE c_birthday;

  -- 节日

  -- 根据当前时间查询出来需要今天发送的整个关怀表的所有短信
  OPEN c_holiday;
	
		-- 执行循环  
		holidayLoop:LOOP  
	-- 判断是否结束循环  
			-- set nflag = nflag + 1;
			IF holidaydone=1 THEN  
				LEAVE holidayLoop; 
			END IF;
  FETCH c_holiday
    INTO tmp_groupid, tmp_userid, TMP_caller, tmp_tally, TMP_MESSAGE;
    -- 查询该用户是否可以下发关怀短信，若不可以直接下一个号码
    select count(*)
      into tmp_count
      from GJDX_USER
     where is_valid = 'Y'
       and status_gh = 'Y'
       and user_name = TMP_caller;
    if tmp_count = 0 then
      -- continue;
			iterate holidayLoop;
    end if;
    OPEN c_GJDX_client1;
		
		clientLoop2:LOOP  
	-- 判断是否结束循环  
			-- set nflag = nflag + 1;
			IF clientdone2=1 THEN  
				LEAVE clientLoop2; 
			END IF;
    FETCH c_GJDX_client1
      INTO TMP_called;
      
        -- 查询生日短信是否要拆分开
        -- 不需要拆分
        IF tmp_tally = '1' THEN
          select count_num
            into tmp_smscount
            from GJDX_SMSCOUNT
           where telephone = TMP_caller;
          if tmp_smscount > 0 then
            INSERT INTO EC_TBL_SHORTMESSAGE
              (SMSID,
               OWNER,
               CALLER,
               ORGTYPE,
               ORGID,
               SMSMESSAGE,
               MESSAGE,
               CREATETIME,
               STATUS,
               OPERATORNO)
            VALUES
              (EC_SEQ_SMS_TMP.NEXTVAL,
               TMP_called,
               TMP_caller,
               '0',
               '0',
               '',
               TMP_MESSAGE,
               sysdate(),
               '0',
               '0');
          
            UPDATE EC_TBL_USER_SEND_COUNT
               SET IN_COUNT = IN_COUNT + 1
             WHERE USER_ID = tmp_userid;
          
            update GJDX_SMSCOUNT
               set count_num = count_num - 1
             WHERE telephone = TMP_CALLER;
            commit;
          end if;
          -- 需要拆分
        ELSEIF tmp_tally = '2' THEN
          select count_num
            into tmp_smscount
            from GJDX_SMSCOUNT
           where telephone = TMP_caller;
          if tmp_smscount > 1 then
            -- 65个字符一组
            SELECT SUBSTR(TMP_MESSAGE, 0, 65) into TMP_MESSAGE1 FROM DUAL;
          
            INSERT INTO EC_TBL_SHORTMESSAGE
              (SMSID,
               OWNER,
               CALLER,
               ORGTYPE,
               ORGID,
               SMSMESSAGE,
               MESSAGE,
               CREATETIME,
               STATUS,
               OPERATORNO)
            VALUES
              (EC_SEQ_SMS_TMP.NEXTVAL,
               TMP_CALLEd,
               TMP_caller,
               '0',
               '0',
               '',
               TMP_MESSAGE1,
               sysdate(),
               '0',
               '0');
          
            SELECT SUBSTR(TMP_MESSAGE, 66) into TMP_MESSAGE2 FROM DUAL;
            INSERT INTO EC_TBL_SHORTMESSAGE
              (SMSID,
               OWNER,
               CALLER,
               ORGTYPE,
               ORGID,
               SMSMESSAGE,
               MESSAGE,
               CREATETIME,
               STATUS,
               OPERATORNO)
            VALUES
              (EC_SEQ_SMS_TMP.NEXTVAL,
               TMP_CALLEd,
               TMP_caller,
               '0',
               '0',
               '',
               TMP_MESSAGE2,
               sysdate(),
               '0',
               '0');
          
            -- 条数计费
            UPDATE EC_TBL_USER_SEND_COUNT
               SET IN_COUNT = IN_COUNT + 2
             WHERE USER_ID = tmp_userid;
          
            update GJDX_SMSCOUNT
               set count_num = count_num - 2
             WHERE telephone = TMP_CALLER;

          end if;
        END IF;
    
    END LOOP clientLoop2;
    CLOSE c_GJDX_client1;
  
  END LOOP holidayLoop;
  CLOSE c_holiday;
	end;
END;

