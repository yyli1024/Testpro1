create
    definer = root@`%` procedure PRO_HANGUPSMS_CANCEL_USER(IN IN_ACCOUNTNO varchar(50), IN IN_EXTNO varchar(20),
                                                           IN IN_PASSWORD varchar(30), IN IN_ID varchar(40),
                                                           IN IN_MOBILE varchar(20), IN IN_BUSINESS varchar(50),
                                                           IN IN_CONTENT varchar(1024), IN IN_COUNT varchar(10),
                                                           IN IN_PRODUCTID varchar(10), OUT EXEC_RESULT varchar(20))
mdc:BEGIN
	 
	 declare TMP_COUNT                 int;
   declare TMP_USER                  VARCHAR(20);
   declare TMP_VALID                 VARCHAR(10); -- 是否立即生效（Y:立即生效，NM:下月神效）
   declare TMP_NEXT_IS_VALID         VARCHAR(10); -- 下月的状态
   declare TMP_IS_VALID              VARCHAR(10); -- 当前的状态
   declare TMP_USERID                int; -- 用户id
   declare TMP_DECRYPTIONUSERNAME    varchar(30);
   declare TMP_DECRYPTIONPHONENYMBER varchar(30);
   declare TMP_USERTYPE              varchar(10);
	 
	 
	 set TMP_DECRYPTIONUSERNAME    = IN_MOBILE;
   set TMP_DECRYPTIONPHONENYMBER = IN_MOBILE;
   set TMP_USER                  = IN_MOBILE;
   set TMP_USERTYPE              = '1';
  
		
	
    -- 判断号码是否为11位，若不足11位则为固话号码（暂不考虑区号）
    if length(IN_MOBILE) < 11 then
      set TMP_USERTYPE = '2';
    end if;
  
    INSERT INTO GJDX_TBL_CANCEL_USER
      (accountno,
       extno,
       password,
       markid,
       mobile,
       business,
       content,
			 count,
			 productid,
       createtime)
    VALUES
      (IN_ACCOUNTNO,
       IN_EXTNO,
       IN_PASSWORD,
       IN_ID,
       IN_MOBILE,
       IN_BUSINESS,
       IN_CONTENT,
			 IN_COUNT,
			 IN_PRODUCTID,
       SYSDATE());
		
		
		  -- 订购用户表中没该用户数据
      SELECT COUNT(*)
        INTO TMP_COUNT
        FROM GJDX_USER
       WHERE TELEPHONE = TMP_USER
         AND IS_VALID = 'Y';
      IF TMP_COUNT = 0 THEN
        set EXEC_RESULT = '1';
        leave mdc;
      END IF;
    
      -- 订购用户表中没该用户数据
      SELECT USER_ID
        INTO TMP_USERID
        FROM GJDX_USER
       WHERE TELEPHONE = TMP_USER
         AND IS_VALID = 'Y';
    
      -- 套餐下发表中没该用户数据
      SELECT COUNT(*)
        INTO TMP_COUNT
        FROM GJDX_SMSCOUNT
       WHERE TELEPHONE = TMP_USER
         AND IS_VALID = 'Y';
      IF TMP_COUNT = 0 THEN
        set EXEC_RESULT = '1';
        leave mdc;
      END IF;

    
      update GJDX_SMSCOUNT
         set IS_VALID      = 'N',
             IS_EFFECTIVE  = '',
             NEXT_IS_VALID = ''
       where IS_VALID = 'Y'
         and telephone = TMP_USER;

			update GJDX_USER
				 set CANCEL_DATE   = sysdate(),
						 IS_VALID      = 'N',
						 IS_EFFECTIVE  = '',
						 NEXT_IS_VALID = ''
			 where IS_VALID = 'Y'
				 and telephone = TMP_USER;

    
      -- 取消挂机短信用户相关策略
			insert into EC_TBL_NUMBER_POOL(caller,operation,status,createtime) values(TMP_USER,'C','0',sysdate());
    
      -- 判断策略中是否有这个userid的策略
      select count(*)
        into tmp_count
        from GJDX_strate
       where user_id = TMP_USERID;
      if tmp_count > 0 then
        update GJDX_strate set is_valid = 'N' where user_id = TMP_USERID;
      end if;
    
      -- 取消用户的相关策略
      call EC_PRO_DELETE_POLICIES('',
                                   TMP_USER,
                                   '',
                                   '',
                                   '',
                                   '',
                                   '',
                                   EXEC_RESULT);

		
END;

