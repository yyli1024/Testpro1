create
    definer = root@`%` procedure PRO_HANGUPSMS_UPDATE_PACKAGE(IN IN_FUNCTIONAL_ID varchar(20),
                                                              IN IN_USER_ID varchar(10), IN IN_USER_NAME varchar(30),
                                                              IN IN_TELEPHONE varchar(30), IN IN_REG_TIME varchar(20),
                                                              IN IN_CANCEL_TIME varchar(20),
                                                              IN IN_TAOCAN_ID varchar(10),
                                                              IN IN_NEXTTAOCAN_ID varchar(10),
                                                              IN IN_EFFECTIVE varchar(10), IN IN_IS_PACKEG varchar(10),
                                                              IN IN_PACKAGE_ID varchar(10),
                                                              IN IN_PACKAGE_LOG varchar(10),
                                                              OUT EXEC_RESULT varchar(20))
mdc:BEGIN

	  declare TMP_COUNT                 int;
    declare TMP_USERNAME              VARCHAR(40);
    declare TMP_TAOCANID              int;
    declare TMP_NEXT_TAOCANID         int;
    declare TMP_MSGCOUNT              int;
    declare TMP_NEXTMSGCOUNT          int;
    declare TMP_PACKAGECOUNT          int;
    declare TMP_GNFY                  VARCHAR(10);
    declare TMP_DECRYPTIONUSERNAME    varchar(30);
    declare TMP_DECRYPTIONPHONENYMBER varchar(30);
    declare TMP_USERTYPE              varchar(10);
	 
	  set TMP_DECRYPTIONUSERNAME    = IN_USER_NAME;
    set TMP_DECRYPTIONPHONENYMBER = IN_TELEPHONE;
    set TMP_USERNAME              = IN_USER_NAME;
    set TMP_USERTYPE              = '1';
    set TMP_TAOCANID      = TO_NUMBER(IN_TAOCAN_ID);
    set TMP_NEXT_TAOCANID = TO_NUMBER(IN_NEXTTAOCAN_ID);
		
	
    -- 判断号码是否为11位，若不足11位则为固话号码（暂不考虑区号）
    if length(IN_USER_NAME) < 11 then
      set TMP_USERTYPE = '2';
    end if;
  
    INSERT INTO GJDX_TBL_UPDATE_PACKAGE
      (functionalid,
       userid,
       username,
       telephone,
       regtime,
       canceltime,
       taocanid,
       nexttaocanid,
       iseffective,
       ispackeg,
       packageid,
       packagelog,
       createtime)
    VALUES
      (IN_FUNCTIONAL_ID,
       IN_USER_ID,
       TMP_DECRYPTIONUSERNAME,
       TMP_DECRYPTIONPHONENYMBER,
       IN_REG_TIME,
       IN_CANCEL_TIME,
       IN_TAOCAN_ID,
       IN_NEXTTAOCAN_ID,
       IN_EFFECTIVE,
       IN_IS_PACKEG,
       IN_PACKAGE_ID,
       IN_PACKAGE_LOG,
       SYSDATE());
		
		 SELECT COUNT(*)
        INTO TMP_COUNT
        FROM GJDX_USER
       WHERE TELEPHONE = TMP_DECRYPTIONUSERNAME
         AND IS_VALID = 'Y';
      IF TMP_COUNT = 0 THEN
        set EXEC_RESULT = '1';
        leave mdc;
      END IF;
      -- 判断接口传的两个套餐是否正确
      -- 判断本月套餐ID是否有效
      SELECT COUNT(*)
        INTO TMP_COUNT
        FROM GJDX_TAOCAN
       WHERE TAOCAN_ID = IN_TAOCAN_ID
         AND IS_VALID = 'Y';
      IF TMP_COUNT = 0 THEN
        set EXEC_RESULT = '1';
        leave mdc;
      END IF;
    
      -- 判断下月套餐ID是否有效
      SELECT COUNT(*)
        INTO TMP_COUNT
        FROM GJDX_TAOCAN
       WHERE TAOCAN_ID = IN_NEXTTAOCAN_ID
         AND IS_VALID = 'Y';
      IF TMP_COUNT = 0 THEN
        set EXEC_RESULT = '1';
        leave mdc;
      END IF;
    
      -- 查询当前套餐的条数信息
      SELECT MSG_COUNT, TAOCAN_JE
        INTO TMP_MSGCOUNT, TMP_GNFY
        FROM GJDX_TAOCAN
       WHERE TAOCAN_ID = IN_TAOCAN_ID
         AND IS_VALID = 'Y';
      -- 查询下月套餐条数信息
      SELECT MSG_COUNT
        INTO TMP_NEXTMSGCOUNT
        FROM GJDX_TAOCAN
       WHERE TAOCAN_ID = IN_NEXTTAOCAN_ID
         AND IS_VALID = 'Y';
    
      -- 判断修改套餐的时候是否加了叠加包
      if IN_PACKAGE_ID is not null then
        SELECT COUNT(*)
          INTO TMP_COUNT
          FROM GJDX_TAOCAN
         WHERE TAOCAN_ID = IN_PACKAGE_ID
           AND IS_VALID = 'Y';
        if TMP_COUNT > 0 then
          -- 查询当前叠加包的条数信息
          SELECT MSG_COUNT
            INTO TMP_PACKAGECOUNT
            FROM GJDX_TAOCAN
           WHERE TAOCAN_ID = IN_PACKAGE_ID
             AND IS_VALID = 'Y';
        
          -- 将叠加包的信息放入叠加包表中，只用于记录
          if IN_EFFECTIVE = 'Y' then
            INSERT INTO GJDX_TBL_USER_PACKAGE
              (USERPHONENUMBER,
               PACKAGE_ID,
               PACKAGE_LOG,
               IS_VALID,
               CREATETIME,
               IS_EFFECTIVE,
               NEXT_IS_VALID)
            VALUES
              (TMP_DECRYPTIONUSERNAME,
               IN_PACKAGE_ID,
               IN_PACKAGE_LOG,
               'Y',
               SYSDATE,
               'Y',
               'Y');

          elseif IN_EFFECTIVE = 'N' then
            INSERT INTO GJDX_TBL_USER_PACKAGE
              (USERPHONENUMBER,
               PACKAGE_ID,
               PACKAGE_LOG,
               IS_VALID,
               CREATETIME,
               IS_EFFECTIVE,
               NEXT_IS_VALID)
            VALUES
              (TMP_DECRYPTIONUSERNAME,
               IN_PACKAGE_ID,
               IN_PACKAGE_LOG,
               'N',
               SYSDATE,
               'N',
               'Y');
          end if;
        else
          set EXEC_RESULT = 1;
          leave mdc;
        end if;
      end if;
    
      -- 判断用户选择是否为立即生效
      if IN_EFFECTIVE = 'Y' then
        update GJDX_SMSCOUNT
           set count_num  = TMP_NEXTMSGCOUNT + TMP_PACKAGECOUNT,
               month_num  = TMP_NEXTMSGCOUNT,
               taocan_num = TMP_NEXTMSGCOUNT
         where IS_VALID = 'Y'
           and telephone = TMP_DECRYPTIONUSERNAME;
        update GJDX_USER
           set taocan_id      = TMP_NEXT_TAOCANID,
               next_taocan_id = TMP_NEXT_TAOCANID
         where IS_VALID = 'Y'
           and telephone = TMP_DECRYPTIONUSERNAME;
        UPDATE GJDX_USER
           SET GNFY = TMP_GNFY
         WHERE IS_VALID = 'Y'
           and telephone = TMP_DECRYPTIONUSERNAME;
      elseif IN_EFFECTIVE = 'N' then
        update GJDX_SMSCOUNT
           set month_num  = TMP_NEXTMSGCOUNT + TMP_PACKAGECOUNT,
               taocan_num = TMP_NEXTMSGCOUNT
         where IS_VALID = 'Y'
           and telephone = TMP_DECRYPTIONUSERNAME;
        update GJDX_USER
           set taocan_id = TMP_TAOCANID, next_taocan_id = TMP_NEXT_TAOCANID
         where IS_VALID = 'Y'
           and telephone = TMP_DECRYPTIONUSERNAME;
      end if;
		
END;

