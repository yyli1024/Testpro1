create
    definer = root@`%` procedure PRO_UPDATE_GJDX_TAOCAN()
mdc:BEGIN
	declare tmp_userid varchar(20);
	declare tmp_taocanid varchar(20);
	declare tmp_nexttaocanid varchar(20);
	declare tmp_telephone varchar(20);
	declare done int; 
	
	 declare C_JOB CURSOR for 
    SELECT USER_ID, TAOCAN_ID, NEXT_TAOCAN_ID, TELEPHONE
      FROM GJDX_USER
     WHERE NEXT_TAOCAN_ID <> 0
       AND IS_VALID = 'Y'
       AND CANCEL_DATE IS NULL;

	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done=1; 
	-- 打开游标  
	open C_JOB;
	-- 执行循环  
		poaLoop:LOOP  
	-- 判断是否结束循环  
			IF done=1 THEN  
				LEAVE poaLoop; 
			END IF;
	-- 取游标中的值  
			FETCH  C_JOB into tmp_userid,tmp_taocanid,tmp_nexttaocanid,tmp_telephone;
			
			 UPDATE GJDX_USER
       SET TAOCAN_ID = tmp_taocanid
     WHERE USER_ID = tmp_userid;
    INSERT INTO GJDX_TAOCAN_UPDATE_RECORD
    VALUES
      (tmp_userid,
       SYSDATE,
       tmp_taocanid,
       tmp_nexttaocanid,
       tmp_telephone);

			END LOOP poaLoop;  
	-- 释放游标  
	CLOSE C_JOB; 
END;

