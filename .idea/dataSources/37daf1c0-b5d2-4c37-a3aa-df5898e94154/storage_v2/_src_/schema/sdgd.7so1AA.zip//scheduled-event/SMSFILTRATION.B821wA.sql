create definer = root@`%` event SMSFILTRATION on schedule
    every '3' SECOND
        starts '2019-11-12 14:06:26'
    enable
    do
    Begin
Call EC_PRO_SMS_FILTRATION(@EXEC_OUT);
End;

