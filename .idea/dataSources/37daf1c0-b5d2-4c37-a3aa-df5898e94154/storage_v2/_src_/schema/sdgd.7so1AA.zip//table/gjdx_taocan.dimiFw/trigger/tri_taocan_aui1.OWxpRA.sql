create definer = root@`%` trigger TRI_TAOCAN_AUI1
    after update
    on gjdx_taocan
    for each row
    UPDATE EC_TBL_TAOCAN
         SET TAOCAN_JE   = NEW.TAOCAN_JE,
             MSG_COUNT   = NEW.MSG_COUNT,
             C_ZF        = NEW.C_ZF,
             IS_VALID    = NEW.IS_VALID,
             TAOCAN_NAME = NEW.TAOCAN_NAME,
             IS_HID      = NEW.IS_HID
       WHERE TAOCAN_ID = NEW.TAOCAN_ID;

