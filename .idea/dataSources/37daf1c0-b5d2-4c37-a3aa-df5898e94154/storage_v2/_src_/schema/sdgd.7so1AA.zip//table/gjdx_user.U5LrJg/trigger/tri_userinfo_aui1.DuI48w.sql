create definer = root@`%` trigger TRI_USERINFO_AUI1
    after update
    on gjdx_user
    for each row
begin
 IF OLD.TAOCAN_ID <> NEW.TAOCAN_ID THEN
        UPDATE EC_TBL_USER
           SET USER_NAME        = TRIM(NEW.USER_NAME),
               TELEPHONE        = TRIM(NEW.TELEPHONE),
               IS_LOCKED        = NEW.IS_LOCKED,
               IS_VALID         = NEW.IS_VALID,
               TAOCAN_ID        = NEW.TAOCAN_ID,
               IS_GON           = NEW.IS_GON,
               CREATETIME       = NEW.REG_DATE,
               UPDATETIME       = SYSDATE(),
               PARENT_ID        = NEW.PARENT_ID,
               BIND_PHONENUMBER = NEW.MOBILE
         WHERE USER_ID = NEW.USER_ID;
      ELSE
        IF (NEW.IS_LOCKED = 'Y' AND NEW.IS_VALID = 'N') THEN
          UPDATE EC_TBL_USER
             SET USER_NAME        = TRIM(NEW.USER_NAME),
                 TELEPHONE        = TRIM(NEW.TELEPHONE),
                 IS_LOCKED        = NEW.IS_LOCKED,
                 IS_VALID         = NEW.IS_VALID,
                 TAOCAN_ID        = NEW.TAOCAN_ID,
                 IS_GON           = NEW.IS_GON,
                 UPDATETIME       = NEW.CANCEL_DATE,
                 PARENT_ID        = NEW.PARENT_ID,
                 BIND_PHONENUMBER = NEW.MOBILE
           WHERE USER_ID = NEW.USER_ID;
        ELSE
          UPDATE EC_TBL_USER
             SET USER_NAME        = TRIM(NEW.USER_NAME),
                 TELEPHONE        = TRIM(NEW.TELEPHONE),
                 IS_LOCKED        = NEW.IS_LOCKED,
                 IS_VALID         = NEW.IS_VALID,
                 TAOCAN_ID        = NEW.TAOCAN_ID,
                 IS_GON           = NEW.IS_GON,
                 UPDATETIME       = SYSDATE(),
                 PARENT_ID        = NEW.PARENT_ID,
                 BIND_PHONENUMBER = NEW.MOBILE
           WHERE USER_ID = NEW.USER_ID;
        END IF;
      END IF;

      IF UPPER(NEW.IS_VALID) = 'N' THEN
        UPDATE EC_TBL_USER
           SET PARENT_ID = 0
         WHERE PARENT_ID = NEW.USER_ID;
      END IF;
end;

