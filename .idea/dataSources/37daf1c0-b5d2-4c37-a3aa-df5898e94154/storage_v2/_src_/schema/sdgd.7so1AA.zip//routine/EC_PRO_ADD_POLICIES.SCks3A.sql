create
    definer = root@`%` procedure EC_PRO_ADD_POLICIES(IN IN_PID varchar(20), IN IN_PHONENUMBER varchar(30),
                                                     IN IN_STARTTIME varchar(30), IN IN_ENDTIME varchar(30),
                                                     IN IN_STATUS varchar(20), IN IN_CYCLEID varchar(20),
                                                     IN IN_MESSAGE varchar(1024), OUT EXEC_RESULT varchar(10))
BEGIN
	  declare TMP_COUNT  INT;
    declare TMP_USERID INT;
    declare TMP_ENCRYPTPHONENUMBER   varchar(30);
		 
	  set TMP_ENCRYPTPHONENUMBER = IN_PHONENUMBER;
    SELECT USERID
      INTO TMP_USERID
      FROM EC_TBL_USERINFO
     WHERE PHONENUMBER = TMP_ENCRYPTPHONENUMBER;
  
    SELECT COUNT(*)
      INTO TMP_COUNT
      FROM EC_TBL_POLICIES
     WHERE PID = IN_PID
       AND USERID = TMP_USERID;
  
    IF TMP_COUNT > 0 THEN
      DELETE FROM EC_TBL_POLICIES
       WHERE PID = IN_PID
         AND USERID = TMP_USERID;
    END IF;
  
    INSERT INTO EC_TBL_POLICIES
      (PID,
       USERID,
       CYCLEID,
       MESSAGE,
       STARTTIME,
       ENDTIME,
       STATUS,
       is_valid,
       is_stop,
       tally)
    VALUES
      (IN_PID,
       TMP_USERID,
       IN_CYCLEID,
       IN_MESSAGE,
       IN_STARTTIME,
       IN_ENDTIME,
       IN_STATUS,
       'Y',
       'N',
       '1');

    set EXEC_RESULT = '0';
    -- RETURN;
END;

