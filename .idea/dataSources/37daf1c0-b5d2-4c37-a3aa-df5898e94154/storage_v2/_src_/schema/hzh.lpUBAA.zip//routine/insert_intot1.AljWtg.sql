create
    definer = root@`%` procedure insert_intot1(IN in_id int)
mdc:BEGIN

	declare tmp_count int;
	declare done int; 
	declare nflag int;
	
	set tmp_count := 0;
	set done:= 1;
	set nflag:= 0;
	
	if tmp_count = 1 or (done = 1 and nflag = 1) then
		leave mdc;
	else
		insert into t1 values(in_id,'7273727387287');
	end if;
	
END;

