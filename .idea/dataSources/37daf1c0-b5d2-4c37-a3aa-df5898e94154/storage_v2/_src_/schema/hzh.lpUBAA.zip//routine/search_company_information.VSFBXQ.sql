create
    definer = root@`%` procedure search_company_information(IN message varchar(100), OUT voicepartone varchar(100),
                                                            OUT voiceparttwo varchar(100),
                                                            OUT voicepartthree varchar(100))
BEGIN
	declare tmp_count int;
	declare done int; 
	declare nflag int;
	declare companyinfo varchar(100);
	declare result varchar(100);
	declare cur_test CURSOR for select description from ec_tbl_company_info where name like companyinfo limit 3;
		 
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done=1; 

	set voiceparttwo = '';
	set nflag = 0;
	
	set companyinfo = concat('%',message,'%');
	-- 打开游标  
	open cur_test;
	-- 执行循环  
		poaLoop:LOOP  
	-- 判断是否结束循环  
			set nflag = nflag + 1;
			IF done=1 THEN  
				LEAVE poaLoop; 
			END IF;
	-- 取游标中的值  
			FETCH  cur_test into result;
			if result is not null then 
				if nflag = 1 then
					set voicepartone = concat('第一条信息为',result);
				ELSEIF nflag = 2 then
					set voiceparttwo = concat('第二条信息为',result);
				else
					set voicepartthree = concat('第三条信息为',result);
				end if;
			end if;
			
			set result = null;
			-- set voiceparttwo = CONCAT(voiceparttwo,result2);
			-- set result2 = '';
			END LOOP poaLoop;  
	-- 释放游标  
	CLOSE cur_test;  
END;

