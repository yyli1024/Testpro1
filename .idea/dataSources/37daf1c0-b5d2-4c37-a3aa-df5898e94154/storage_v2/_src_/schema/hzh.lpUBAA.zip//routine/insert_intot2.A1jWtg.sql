create
    definer = root@`%` procedure insert_intot2(IN in_id int, OUT out_phonenumber varchar(20))
BEGIN
  insert into t1 values(in_id,'7273727387287');
  set out_phonenumber='18877872723';
END;

