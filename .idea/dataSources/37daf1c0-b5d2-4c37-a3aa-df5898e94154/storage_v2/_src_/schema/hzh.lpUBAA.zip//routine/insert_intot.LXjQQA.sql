create
    definer = root@`%` procedure insert_intot()
mdc:BEGIN

	
	/* DECLARE COUNT INT DEFAULT 0;
    DECLARE SUM INT DEFAULT 0;
    WHILE COUNT < 1000 DO
       insert into ec_dxqf_shortmessage(sendno,accessnumber,message,sendtime,endtime,priorityid,status,orgtype,smsid,eventtype,sendrate,validhour) select sendno,accessnumber,message,sendtime,endtime,priorityid,status,orgtype,smsid,eventtype,sendrate,validhour from ec_dxqf_shortmessage_temp_copy1;
        SET COUNT = COUNT + 1;
    END WHILE;*/
  --  SELECT SUM;
	
	if left('18855972619',1) = '1' then
		select 'ok';
	end if;
	
END;

