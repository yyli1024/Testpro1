create
    definer = root@`%` procedure pro_clean_sms()
BEGIN
SELECT COUNT(*) FROM EC_TBL_SHORTMESSAGE;
END;

